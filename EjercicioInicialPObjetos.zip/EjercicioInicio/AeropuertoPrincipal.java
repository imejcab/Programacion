package EjercicioInicio;
import java.util.Scanner;
public class AeropuertoPrincipal {
	public static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("1. Crear avion solo con un identificador" + "\n" + "2. Crear avion con el identificador y la compañia");
		int opcion=0;
		do {
			System.out.println("Dime que opcion quieres (1 o 2)");
			opcion=Integer.valueOf(sc.nextLine());
		}while(opcion<1 & opcion>2);
		/*switch(opcion) {
		case 1:
			Avion p1=new Avion("1234",200);
			break;
		case 2:
			Avion p2=new Avion("1234",200,"iberia");
			break;
		}*/
		Avion p1=new Avion("1234",200,0,0,"iberia");
		int opcion2=1;
		int numVuelos=0;
		double kmVolados=0;
		double contadorKmVolados=0;
		int asientosUsados=0;
		while(opcion2<7 & opcion2>0) {
			do {
				System.out.println("Dime una opcion del 1 al 7");
				opcion2=Integer.valueOf(sc.nextLine());
			}while(opcion2>7 & opcion2<1);
			switch(opcion2) {
			case 1:
				System.out.println("Dime cuantos asientos asignados");
				asientosUsados=Integer.valueOf(sc.nextLine());
				System.out.println("Cuantos km se realizan");
				kmVolados=Double.valueOf(sc.nextLine());
				System.out.println(p1.asignarVuelo(200,asientosUsados,numVuelos, contadorKmVolados, kmVolados));
			break;
			case 2:
				System.out.println(p1.numeroVuelos(numVuelos));
				break;
			case 3:
				System.out.println(p1.getTotalKm(kmVolados));
				break;
			case 4:
				System.out.println(p1.getMediaKm(numVuelos, kmVolados));
				break;
			case 5:
				System.out.println("La compañia es " + p1.getCompannia());
				String nuevaCompañia="Luftansa";
				p1.setCompannia(nuevaCompañia);
				System.out.println("La nueva compañia es " + p1.getCompannia());
				break;
			case 6:
				System.out.println("Avion con id: " + p1.getIdAvion() + " de la compañia " + p1.getCompannia() + " ha realizado " + p1.getNumVuelos() + " vuelos, con un total de " + p1.getKmVolados() + " km y una media de " + p1.getMediaKm(numVuelos, kmVolados) + " por vuelo ");
			}
		}
	}
}
