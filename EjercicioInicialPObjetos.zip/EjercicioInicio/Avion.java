package EjercicioInicio;
public class Avion {
	/*Atributos*/
	private String idAvion;
	private int capacidad;
	private int numVuelos;
	private double kmVolados;
	private String compannia;
	/*Constructores*/
	public Avion(String idAvion, int capacidad, int numVuelos, double kmVolados, String compannia) {
		super();
		this.idAvion = idAvion;
		this.capacidad = capacidad;
		this.numVuelos = numVuelos;
		this.kmVolados = kmVolados;
		this.compannia = compannia;
	}
	public Avion(String idAvion, int capacidad, String compannia) {
		super();
		this.idAvion = idAvion;
		this.capacidad = capacidad;
		this.compannia = compannia;
	}
	public Avion(String idAvion, int capacidad) {
		super();
		this.idAvion = idAvion;
		this.capacidad = capacidad;
	}
	/*Metodos*/
	public String getIdAvion() {
		return idAvion;
	}
	public int getCapacidad() {
		return capacidad;
	}
	public int getNumVuelos() {
		return numVuelos;
	}
	public void setNumVuelos(int numVuelos) {
		this.numVuelos = numVuelos;
	}
	public double getKmVolados() {
		return kmVolados;
	}
	public void setKmVolados(double kmVolados) {
		this.kmVolados = kmVolados;
	}
	public String getCompannia() {
		return compannia;
	}
	public void setCompannia(String compannia) {
		this.compannia = compannia;
	}
	public boolean asignarVuelo(int capacidad, int asientosUsados, int numVuelos, double contadorKmVolados, double kmVolados) {
		boolean esAsignado=false;
		if((asientosUsados<=capacidad) & kmVolados>0) {
			esAsignado=true;
			contadorKmVolados+=kmVolados;
			numVuelos++;
		}
		return esAsignado;
	}
	public int numeroVuelos(int numVuelos) {
		return numVuelos;
	}
	public double getTotalKm(double kmVolados) {
		return kmVolados;
	}
	public double getMediaKm(int numVuelos, double kmVolados) {
		double mediaKilometrosVuelo=kmVolados/numVuelos;
		return mediaKilometrosVuelo;
	}
}
