package elementos.TestCoordenadas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import elementos.Coordenada;
import elementos.JugadorException;

class TestCoordenada {
	@Test
	void testCoordenadaCorrecto() {
		try {
			Coordenada uno= new Coordenada(2,8);
		} catch (JugadorException e) {
			assert(false);
		}
	}
	void testCoordenadaIncorrecto() {
		try {
			Coordenada uno= new Coordenada(20,8);
		} catch (JugadorException e) {
			assert(true);
		}
	}
	@Test
	void testGoRightCorrecto() throws JugadorException {
		Coordenada uno= new Coordenada(2,8);
		assertTrue(uno.goRight());
		assertEquals(uno.getX(), 2);
		assertNotEquals(uno.getY(),1);
	}
	@ParameterizedTest
	@ValueSource(strings= {"2","-1","10"})
	void testGoRightCorrectoParameter(int valor) throws JugadorException {
		Coordenada uno= new Coordenada(2,8);
		assertTrue(uno.goRight());
		assertEquals(uno.getX(), valor);
		assertNotEquals(uno.getY(),valor);
	}
	@Test
	void testGoRightIncorrecto() throws JugadorException {
		Coordenada uno= new Coordenada(10,8);
		assertFalse(uno.goRight());
		assertEquals(uno.getX(), 2);
		assertNotEquals(uno.getY(),8);
	}
	@Test
	void testGoLeftCorrecto() throws JugadorException {
		Coordenada uno= new Coordenada(1,8);
		assertTrue(uno.goLeft());
		assertEquals(uno.getX(), 2);
		assertNotEquals(uno.getY(),1);
	}
	@ParameterizedTest
	@ValueSource(strings= {"2","-1","10"})
	void testGoLeftCorrectoParameter(int valor) throws JugadorException {
		Coordenada uno= new Coordenada(0,8);
		assertTrue(uno.goLeft());
		assertEquals(uno.getX(), valor);
		assertNotEquals(uno.getY(),valor);
	}
	@Test
	void testGoLeftIncorrecto() throws JugadorException {
		Coordenada uno= new Coordenada(0,8);
		assertFalse(uno.goLeft());
		assertEquals(uno.getX(), 2);
		assertNotEquals(uno.getY(),8);
	}
	@Test
	void testGoDownCorrecto() throws JugadorException {
		Coordenada uno= new Coordenada(4,8);
		assertTrue(uno.goDown());
	}
	@ParameterizedTest
	@ValueSource(strings= {"2","-1","10"})
	void testGoDownCorrectoParameter(int valor) throws JugadorException {
		Coordenada uno= new Coordenada(4,8);
		assertTrue(uno.goDown());
		assertEquals(uno.getX(), valor);
		assertNotEquals(uno.getY(),valor);
	}
	@Test
	void testGoDownIncorrecto() throws JugadorException {
		Coordenada uno= new Coordenada(4,0);
		assertFalse(uno.goDown());
	}
	@Test
	void testGoUpCorrecto() throws JugadorException {
		Coordenada uno= new Coordenada(0,8);
		assertTrue(uno.goUp());
	}
	@ParameterizedTest
	@ValueSource(strings= {"2","-1","8"})
	void testGoUpCorrectoParameter(int valor) throws JugadorException {
		Coordenada uno= new Coordenada(0,8);
		assertTrue(uno.goRight());
		assertEquals(uno.getX(), valor);
		assertNotEquals(uno.getY(),valor);
	}
	@Test
	void testGoUpIncorrecto() throws JugadorException {
		Coordenada uno= new Coordenada(0,10);
		assertFalse(uno.goUp());
	}
	@Test
	void testDone() {
		//valor random
	}
}
