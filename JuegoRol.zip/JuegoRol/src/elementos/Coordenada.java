package elementos;

import java.util.Objects;

import logicaJuego.Constantes;

public class Coordenada {
	private int x;
	private int y;
	public Coordenada() {
		super();
	}
	public Coordenada(int x, int y) throws JugadorException {
		super();
		this.x = setX(x);
		this.y = setY(y);
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public int setX(int x) throws JugadorException {
		if(this.x>Constantes.TAMANNO || this.x<=0) {
			throw new JugadorException("La coordenada no existe");
		}
		return x;
	}
	public int setY(int y) throws JugadorException {
		if(this.y>Constantes.TAMANNO || this.y<=0) {
			throw new JugadorException("La coordenada no existe");
		}
		return y;
	}
	public int hashCode() {
		return Objects.hash(x, y);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=false;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Coordenada other = (Coordenada) obj;
		if(x == other.x && y == other.y) {
			resultado=true;
		}
		return resultado;
	}
	public boolean goRight() {
		boolean esMovida;
		if(x>=Constantes.TAMANNO) {
			esMovida=false;
		}
		this.x=x++;
		esMovida=true;
		return esMovida;
	}
	public boolean goLeft() {
		boolean esMovida;
		if(x<=0) {
			esMovida=false;
		}
		this.x=x--;
		esMovida=true;
		return esMovida;	
	}
	public boolean goUp() {
		boolean esMovida;
		if(y>=Constantes.TAMANNO) {
			esMovida=false;
		}
		this.y=y++;
		esMovida=true;
		return esMovida;
	}
	public boolean goDown() {
		boolean esMovida;
		if(y<=0) {
			esMovida=false;
		}
		this.y=y--;
		esMovida=true;
		return esMovida;
	}
	public Coordenada done() throws JugadorException {
		int numerox=(int) (Math.random()*10+1);
		int numeroy=(int) (Math.random()*10+1);
		return new Coordenada(numerox,numeroy);
	}
}
