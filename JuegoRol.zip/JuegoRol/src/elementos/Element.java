package elementos;

import java.util.Objects;

public class Element {
	private ElementType tipoElemento;
	public Element(ElementType tipoElemento) {
		super();
		this.tipoElemento = tipoElemento;
	}
	public ElementType getType() {
		return tipoElemento;
	}
	public String toString() {
		return String.format("Element [tipoElemento=" + tipoElemento + "]");
	}
	public int hashCode() {
		return Objects.hash(tipoElemento);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=false;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Element other = (Element) obj;
		if(tipoElemento == other.tipoElemento) {
			resultado=true;
		}
		return resultado;
	}
}
