package elementos.TestJugador;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;

import elementos.Jugador;
import elementos.JugadorException;
import elementos.PlayerType;

class TestJugador {

	@Test
	void testJugador() {
		Jugador x= new Jugador (PlayerType.ELFO);
	}

	@Test
	void testLucha() throws JugadorException {
		Jugador x= new Jugador (PlayerType.ELFO);
		Jugador y= new Jugador (PlayerType.MAGO);
		assertTrue(x.lucha(y)==1);
		assertFalse(y.lucha(x)==1);
		assertNull(x.lucha(y)==-1);
		assertEquals(5, x.lucha(y));
	}
	@ParameterizedTest
	@MethodSource("valores")
	void testLuchaParameter(int valor) throws JugadorException {
		Jugador x= new Jugador (PlayerType.ELFO);
		Jugador y= new Jugador (PlayerType.MAGO);
		assertTrue(x.lucha(y)==valor);
		assertFalse(y.lucha(x)==valor);
		assertNull(x.lucha(y)==valor);
		assertEquals(valor, x.lucha(y));
	}
	static List <String> valores(){
		return Arrays.asList("2", "3", "4", "5");
	}
	@Test
	void testEncuentraRoca() {
		Jugador x= new Jugador (PlayerType.ELFO);
		Jugador y= new Jugador (PlayerType.MAGO);
		assertTrue(x.encuentraRoca()==1);
		y.encuentraGema();
		assertTrue(y.encuentraRoca()==0);
		assertFalse(y.getGemas()==1);
		assertTrue(x.encuentraRoca()==2);
	}
	@ParameterizedTest
	@CsvSource({"1,3", "2,2", "3,1"})
	void testEncuentraRoca(int valorX, int valorY) {
		Jugador x= new Jugador (PlayerType.ELFO);
		Jugador y= new Jugador (PlayerType.MAGO);
		assertTrue(x.encuentraRoca()==valorX);
		y.encuentraGema();
		assertTrue(y.encuentraRoca()==0);
		assertFalse(y.getGemas()==1);
		assertTrue(x.encuentraRoca()==valorY);
	}
	@Test
	void testEncuentraDinero() {
		Jugador x= new Jugador (PlayerType.ELFO);
		assertFalse(x.getDinero()==10);
		x.encuentraDinero();
		assertEquals(x.getDinero(),1);
	}

	@Test
	void testEncuentraPocion() {
		Jugador x= new Jugador (PlayerType.ELFO);
		assertFalse(x.getPociones()==2);
		x.encuentraPocion();;
		assertEquals(x.getPociones(),1);
	}

	@Test
	void testEncuentraGema() {
		Jugador x= new Jugador (PlayerType.ELFO);
		assertFalse(x.getGemas()==1);
		x.encuentraGema();
		assertEquals(x.getGemas(), 1);
	}

}
