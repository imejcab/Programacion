package elementos;

import logicaJuego.Constantes;

public class Jugador {
	private int dinero;
	private int pociones;
	private int gemas;
	private PlayerType tipoJugador;
	public Jugador(PlayerType tipoJugador) {
		super();
		this.tipoJugador = tipoJugador;
		this.dinero=0;
		this.pociones=0;
		this.gemas=0;
	}
	public int getDinero() {
		return dinero;
	}
	public void setDinero(int dinero) throws JugadorException {
		if(this.dinero>Constantes.NUM_DINERO) {
			throw new JugadorException("El dinero establecido no es valido");
		}
		this.dinero = dinero;
	}
	public int getPociones() {
		return pociones;
	}
	public void setPociones(int pociones) throws JugadorException {
		if(this.pociones>Constantes.NUM_POCIONES) {
			throw new JugadorException("Las gemas establecidas no son validas");
		}
		this.pociones = pociones;
	}
	public int getGemas() {
		return gemas;
	}
	public void setGemas(int gemas) throws JugadorException {
		if(this.gemas>Constantes.NUM_GEMAS) {
			throw new JugadorException("Las gemas establecidas no son validas");
		}
		this.gemas = gemas;
	}
	public PlayerType getTipoJugador() {
		return tipoJugador;
	}
	public String getNombre() {
		return this.tipoJugador.name();
	}
	private int getFuerza() {
		int fuerza=0;
		if(tipoJugador.ELFO.equals(tipoJugador)) {
			fuerza=(int) Math.random()*Constantes.ELFO_FUERZA+1;
		}else if(tipoJugador.GUERRERO.equals(tipoJugador)) {
			fuerza=(int) Math.random()*Constantes.GUERRERO_FUERZA+1;
		}else if(tipoJugador.MAGO.equals(tipoJugador)) {
			fuerza=(int) Math.random()*Constantes.MAGO_FUERZA+1;
		}else {
			fuerza=(int) Math.random()*Constantes.OGRO_FUERZA+1;
		}
		return fuerza;
	}
	private int getMagia() {
		int magia=0;
		if(tipoJugador.ELFO.equals(tipoJugador)) {
			magia=(int) Math.random()*Constantes.ELFO_MAGIA+1;
		}else if(tipoJugador.GUERRERO.equals(tipoJugador)) {
			magia=(int) Math.random()*Constantes.GUERRERO_MAGIA+1;
		}else if(tipoJugador.MAGO.equals(tipoJugador)) {
			magia=(int) Math.random()*Constantes.MAGO_MAGIA+1;
		}else {
			magia=(int) Math.random()*Constantes.OGRO+1;
		}
		return magia;
	}
	private int getVelocidad() {
		int velocidad=0;
		if(tipoJugador.ELFO.equals(tipoJugador)) {
			velocidad=(int) Math.random()*Constantes.ELFO_VELOCIDAD+1;
		}else if(tipoJugador.GUERRERO.equals(tipoJugador)) {
			velocidad=(int) Math.random()*Constantes.GUERRERO_VELOCIDAD+1;
		}else if(tipoJugador.MAGO.equals(tipoJugador)) {
			velocidad=(int) Math.random()*Constantes.MAGO_VELOCIDAD+1;
		}else {
			velocidad=(int) Math.random()*Constantes.OGRO_VELOCIDAD+1;
		}
		return velocidad;
	}
	public int getFuerzaParaLuchar() {
		return getFuerza();
	}
	public int getMagiaParaLuchar() {
		return getMagia();	
	}
	public int getVelocidadParaLuchar() {
		return getVelocidad();
	}
	public String resumen() {
		return String.format("Jugador [dinero=" + dinero + ", pociones=" + pociones + ", gemas=" + gemas + ", tipoJugador="
				+ tipoJugador + "]");
	}
	public int lucha (Jugador e) throws JugadorException {
		int resultado=0;
		if(this.getPociones()>0 && e.getPociones()==0) {
			if(e.getDinero()==0) {
				this.pociones--;
				resultado=Constantes.GANA_MUERE;
			}else {
				this.dinero+=e.getDinero();
				e.setDinero(0);
				this.pociones--;
				resultado=Constantes.GANA_USA_POCIMA;
			}
		}else if(this.getPociones()==0 && e.getPociones()>0) {
			if(this.getDinero()==0) {
				e.pociones--;
				resultado=Constantes.PIERDE_USA_POCIMA;
			}else {
				e.dinero+=this.getDinero();
				this.setDinero(0);
				e.pociones--;
				resultado=Constantes.PIERDE_MUERE;
			}
		}else {
			if(this.getFuerzaParaLuchar()>e.getFuerzaParaLuchar()) {
				this.dinero+=e.getDinero();
				e.setDinero(0);
				resultado=Constantes.GANA_DINERO;
			}else if(this.getFuerzaParaLuchar()<e.getFuerzaParaLuchar()) {
				e.dinero+=this.getDinero();
				this.setDinero(0);
				resultado=Constantes.PIERDE_DINERO;
			}else {
				resultado=Constantes.EMPATE;
			}
		}
		return resultado;
	}
	public int encuentraRoca() {
		int resultado=0;
		if(this.gemas>0) {
			resultado=Constantes.ROMPE_ROCA_CON_GEMA;
			this.gemas--;
		}else {
			if(this.getMagiaParaLuchar()>4) {
				resultado=Constantes.GANA_A_LA_ROCA;
			}else {
				resultado=Constantes.PIERDE_A_LA_ROCA;
			}
		}
		return resultado;
	}
	public void encuentraDinero() {
		this.dinero++;	
	}
	public void encuentraPocion() {
		this.pociones++;	
	}
	public void encuentraGema() {
		this.gemas++;	
	}
}
