package logicaJuego.TestJuego;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import elementos.Coordenada;
import elementos.JugadorException;
import elementos.PlayerType;
import logicaJuego.Constantes;
import logicaJuego.Juego;
import logicaJuego.JuegoException;

class TestJuego {

	@Test
	void testJuego() {
		Juego x= new Juego (null);
	}

	@Test
	void testAnadirJugadores() {
		Juego x= new Juego (null);
		assertTrue(x.anadirJugadores(PlayerType.ELFO));
		x.anadirJugadores(PlayerType.ELFO);
		assertFalse(x.anadirJugadores(PlayerType.ELFO));
		assertEquals(true, x.anadirJugadores(PlayerType.MAGO));
	}

	@Test
	void testMoverJugador() throws JuegoException, JugadorException {
		Juego x= new Juego (null);
		x.anadirJugadores(PlayerType.OGRO);
		x.anadirJugadores(PlayerType.MAGO);
		try {
			x.moverJugador('N');
		} catch (JuegoException | JugadorException e) {
			assert(false);
		}
		assertEquals(" ", x.moverJugador('S'));
		assertNotNull(x.moverJugador('N'));
	}

	@Test
	void testIsTerminado() throws JugadorException {
		Juego x= new Juego (null);
		x.anadirJugadores(PlayerType.OGRO);
		x.anadirJugadores(PlayerType.MAGO);
		x.anadirJugadores(PlayerType.GUERRERO);
		assertFalse(x.isTerminado());
		x.getJugadores()[1].setDinero(20);
		assertTrue(x.isTerminado());
	}

	@Test
	void testGetNombreJuegadorQueJuega() {
		Juego x= new Juego (null);
		x.anadirJugadores(PlayerType.OGRO);
		assertEquals(x.getNombreJuegadorQueJuega(), x.getJugadores()[x.getJugadorJuega()].getNombre());
	}

	@Test
	void testProximoJugador() {
		Juego x= new Juego (null);
		x.anadirJugadores(PlayerType.OGRO);
		x.anadirJugadores(PlayerType.MAGO);
		assertTrue(x.getJugadorJuega()==0);
		x.proximoJugador();
		assertFalse(x.getJugadorJuega()==1);
		x.proximoJugador();
		assertFalse(x.getJugadorJuega()==1);
	}

	@Test
	void testGetGanador() throws JugadorException {
		Juego x= new Juego (null);
		x.anadirJugadores(PlayerType.OGRO);
		x.anadirJugadores(PlayerType.GUERRERO);
		x.anadirJugadores(PlayerType.MAGO);
		x.anadirJugadores(PlayerType.ELFO);
		x.getJugadores()[0].setDinero(20);
		assertTrue(x.getGanador()=="OGRO");
	}

	@Test
	void testObtenerElementoTablero() {
		Juego x= new Juego (null);
		x.anadirJugadores(PlayerType.OGRO);
		x.anadirJugadores(PlayerType.GUERRERO);
	}

	@Test
	void testObtenerCoordenadaJugadorJuega() {
	}

}
