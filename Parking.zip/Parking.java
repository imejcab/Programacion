package Parking;
import java.util.Arrays;
import java.util.Comparator;
public class Parking{
	public static Integer MAX_CAPACIDAD=50;
	/*Atributos*/
	private Vehiculo [] vehiculo;
	/*Constructor*/
	public Parking() {
		super();
		this.vehiculo = new Vehiculo [MAX_CAPACIDAD];
	}
	/*Metodos*/
	/*public String mostrarVehiculoOrdenadosPorMarcaModelo() {
		StringBuilder sb=new StringBuilder();
		Arrays.sort(this.vehiculo, new MarcaModeloComparator());
		for(Vehiculo v: vehiculo) {
			if(v!=null) {
				sb.append(v);
			}
		}
	}*/
	
	public void aparcarVehiculo(Vehiculo v) {
		boolean aparcado=false;
		for(int i=0; i<this.vehiculo.length && !aparcado;i++) {
			if(vehiculo[i]==null) {
				this.vehiculo [i]= v;
			}
		}
	}
	public Vehiculo[] getVehiculo() {
		return vehiculo;
	}
}
