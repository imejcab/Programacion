package Parking;

public enum Combustible {
	ELECTRICO, GASOIL, GASOLINA, HIBRIDO;
}
