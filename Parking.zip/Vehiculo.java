package Parking;
import java.time.LocalDateTime;
import java.util.Arrays;
public class Vehiculo implements Comparable<Vehiculo> {
	/*Atributos*/
	private String marca;
	private String modelo;
	private String matricula;
	protected Combustible combustible;
	private LocalDateTime fecha_entrada;
	protected TipoVehiculo tipo_vehiculo;
	/*Constructor*/
	public Vehiculo(String marca, String modelo, String matricula, Combustible combustible, LocalDateTime fecha_entrada,
			TipoVehiculo tipo_vehiculo) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.matricula = matricula;
		this.combustible = combustible;
		this.fecha_entrada = LocalDateTime.now();
		this.tipo_vehiculo = tipo_vehiculo;
	}
	/*Metodo*/
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public Combustible getCombustible() {
		return combustible;
	}
	public TipoVehiculo getTipo_vehiculo() {
		return tipo_vehiculo;
	}
	public int compareToFecha (Vehiculo otro) {
		return this.fecha_entrada.compareTo(otro.fecha_entrada);
	}
	public int compareTo(Vehiculo otro) {
		return this.matricula.compareTo(otro.matricula);
	}
}
