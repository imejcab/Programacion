/*package Parking;

import java.util.Comparator;

public class MarcaModeloComparator implements Comparator<Vehiculo> {
	
}*/
