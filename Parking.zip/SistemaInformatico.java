package Parking;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;
import java.time.LocalDateTime;
public class SistemaInformatico {
	public static void main(String [] args) {
		Parking parking =new Parking();
		parking.aparcarVehiculo(new Coche("Renault","Clio", "AAA56789",Combustible.GASOIL, LocalDateTime.now(),TipoVehiculo.AUTOMOVIL));
		parking.aparcarVehiculo(new Coche("Peugeot","200", "AAf56289",Combustible.GASOIL, LocalDateTime.now(),TipoVehiculo.AUTOMOVIL));
		parking.aparcarVehiculo(new Coche("Tesla","Plus", "AAS50789",Combustible.ELECTRICO, LocalDateTime.now(),TipoVehiculo.AUTOMOVIL));
		/*Arrays.sort(vehiculo, new Comparator());
		for(Vehiculo v: vehiculo) {
			System.out.println(v);
		}*/
	}
}
