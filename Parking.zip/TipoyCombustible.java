package Parking;

import java.util.Comparator;

public class TipoyCombustible implements Comparator<Vehiculo> {
	public int compare(Vehiculo v1, Vehiculo v2) {
		int resultado=0;
		if(v1!=null && v2!=null) {
			if(v1.getTipo_vehiculo().compareTo(v2.getTipo_vehiculo())==0) {
				v1.getCombustible().compareTo(v2.getCombustible());
			}else {
				v1.getTipo_vehiculo().compareTo(v2.getTipo_vehiculo());
			}
			}else if(v1==null) {
				resultado=1;
			}else if(v2==null) {
				resultado=1;
			}
		return resultado;
	}
}
