package Parking;

import java.time.LocalDateTime;

public class Moto extends Vehiculo {

	public Moto(String marca, String modelo, String matricula, Combustible combustible, LocalDateTime fecha_entrada,
			TipoVehiculo tipo_vehiculo) {
		super(marca, modelo, matricula, combustible, fecha_entrada, tipo_vehiculo);
	}

}
