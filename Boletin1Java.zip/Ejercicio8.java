package com.edu;
import java.util.Scanner;
public class Ejercicio8 {
	public static void main(String[] args) {
		/*8. Método que pida 15 números y realice su suma*/
		Scanner sc=new Scanner(System.in);
		int suma=0;
		int numero;
		for(int contador=0;contador<15;contador++) {
			System.out.println("Dime un numero");
			numero=Integer.valueOf(sc.nextLine());
			suma+=numero;
		}
		System.out.println(suma);
	}
}
