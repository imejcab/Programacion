package com.edu;

import java.util.Scanner;

public class Ejercicio2 {
	public static void main(String[] args) {
		/*2. Escribe un método que reciba por parámetro el día de la semana (Lunes, Martes,
		Miércoles, etc) y devuelva qué asignatura toca a primera hora ese día.*/
		Scanner sc=new Scanner (System.in);
		String dia_semana;
		do {
			System.out.println("Dime un dia de la semana:");
			dia_semana=sc.nextLine();
		}while(!(dia_semana.equals("lunes")) && !(dia_semana.equals("martes")) && !(dia_semana.equals("miercoles")) && !(dia_semana.equals("jueves")) && !(dia_semana.equals("viernes")));
		switch(dia_semana) {
			case "lunes":
				System.out.println("Matematicas");
				break;
			case "martes":
				System.out.println("Lengua");
				break;
			case "miercoles":
				System.out.println("Ingles");
				break;
			case "jueves":
				System.out.println("Biologia");
				break;
			case "viernes":
				System.out.println("Frances");
				break;
			default:
				System.out.println("Valor no valido");
				break;
		}
	}
}
