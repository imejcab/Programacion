package com.edu;
import java.util.Scanner;
public class Ejercicio14 {
	public static void main(String [] args) {
		/*14. Realiza un programa que vaya pidiendo números hasta que se introduzca un
		número negativo y nos diga cuántos números se han introducido, la media de los
		impares y el mayor de los pares. El número negativo sólo se utiliza para indicar el
		final de la introducción de datos pero no se incluye en el cómputo.*/
		Scanner sc=new Scanner(System.in);
		int numero, contador=0, contador_impares=0, suma=0, media=0, mayor=0;
		do {
			System.out.println("Dime un numero");
			numero=Integer.valueOf(sc.nextLine());
			if(numero>=0){
				contador++;
				if(numero%2==1) {
					suma+=numero;
					contador_impares++;
				}else {
					if(numero>mayor) {
						mayor=numero;
					}
				}
			}
		}while(numero>=0);
		media=suma/contador;
		System.out.println("Se han introducido " + contador + " numeros y la media de impares es " + media + " y el mayor de los numeros pares es " + mayor );
	}
}