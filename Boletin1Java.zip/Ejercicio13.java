package com.edu;
import java.util.Scanner;
public class Ejercicio13 {
	public static void main(String[] args) {
		/*13. Programa que reciba 10 números y nos indique el valor máximo y mínimo.*/
		Scanner sc=new Scanner(System.in);
		int mayor=0, menor=1000;
		int numero;
		for(int contador=0;contador<10;contador++) {
			System.out.println("Dime un numero");
			numero=Integer.valueOf(sc.nextLine());
			if(numero>mayor) {
				mayor=numero;
			}else if(numero<menor) {
				menor=numero;
			}
		}
		System.out.println("El numero mayor es " + mayor + " y el numero menor es " + menor);
	}
}
