package com.edu;
import java.util.Scanner;
public class Ejercicio12 {
	public static void main(String[] args ) {
		/*12. Realiza un programa que pida números hasta que se teclee uno negativo y muestre
		cuántos números se han introducido.*/
		Scanner sc=new Scanner(System.in);
		int numero,contador=0;
		do {
			System.out.println("Dime un numero");
			numero=Integer.valueOf(sc.nextLine());
			contador++;
			System.out.println("Se han introducido " + contador + " numeros");
		}while(numero>=0);
	}
}
