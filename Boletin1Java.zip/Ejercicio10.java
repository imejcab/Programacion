package com.edu;
import java.util.Scanner;
public class Ejercicio10 {
public static void main(String [] args) {
	/*10. Realiza un programa que sume los 100 números siguientes a un número entero y
positivo introducido por teclado. Se debe comprobar que el dato introducido es
correcto (que es un número positivo).*/
	Scanner sc=new Scanner(System.in);
	int numero_positivo;
	int contador=0;
	int suma=0;
	do {
		System.out.println("Dime un numero positivo");
		numero_positivo=Integer.valueOf(sc.nextLine());
	}while(numero_positivo<0);
	while(contador<100) {
		suma+=numero_positivo;
		numero_positivo++;
		contador++;
	}
	System.out.println(suma);
}
}
