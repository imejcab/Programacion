package com.edu;
import java.util.Scanner;
public class Ejercicio18 {
	public static final double PI=3.14;
	public static double calcular_longitud(double radio, double PI) {
		double longitud=2*radio*PI;
		return longitud;
	}
	public static double calcular_area(double radio, double PI) {
		radio=Math.pow(radio,2);
		double area=PI*radio;
		return area;
	}
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		/*18. Realizar un método llamado calcularAreaCirculo que devuelva el área de un círculo
		y otro llamado calcularLongitudCirculo que devuelva su longitud.*/
		System.out.println("Dime un valor para el radio");
		double radio=Double.valueOf(sc.nextLine());
		System.out.println(calcular_longitud(radio, PI));
		System.out.println(calcular_area(radio,PI));
	}
}
