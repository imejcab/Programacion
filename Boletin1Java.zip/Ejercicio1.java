package com.edu;

import java.util.Scanner;

public class Ejercicio1 {
	public static void main(String[] args) {
		/*1. Realiza un método que reciba dos números y devuelva True si uno es múltiplo del
		otro.*/
		Scanner sc= new Scanner (System.in);
		int numero1;
		System.out.println("Dime un numero");
		numero1=Integer.valueOf(sc.nextInt());
		int numero2;
		System.out.println("Dime un numero");
		numero2=Integer.valueOf(sc.nextInt());
		if(numero1%numero2==0) {
			System.out.println("true");
		}else {
			System.out.println("false");
			}
		}
	}
