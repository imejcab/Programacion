package com.edu;
import java.util.Scanner;
public class Ejercicio15 {
	public static void main(String[] args) {
		/*15. Crea un programa que permita sumar N números. El usuario decide cuándo termina
		de introducir números al indicar la palabra ‘fin’.*/
		Scanner sc=new Scanner(System.in);
		String numero_string="t";
		int suma=0;
		while(numero_string != "fin") {
			System.out.println("Dime un numero");
			numero_string=sc.nextLine();
			if(Character.isDigit(numero_string.charAt(0))) {
				int numero=Integer.valueOf(numero_string);
				suma+= numero;
			}
		}
		System.out.println("la suma es: " + suma);
	}
}
