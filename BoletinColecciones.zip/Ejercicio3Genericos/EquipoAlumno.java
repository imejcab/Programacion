package Ejercicio3Genericos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import EquiposDeportivos.Alumno;
import EquiposDeportivos.Equipo;

public class EquipoAlumno <Alumno>{
	private Alumno nombreEquipo;
	private Set <Alumno> grupoAlumno;
	public EquipoAlumno (Alumno nombreEquipo, Set<Alumno> grupoAlumno) {
		super();
		this.nombreEquipo = (Alumno) nombreEquipo;
		this.grupoAlumno =  new HashSet ();
	}
	public EquipoAlumno (Alumno nombreEquipo) {
		super();
		this.nombreEquipo = (Alumno) nombreEquipo;
	}
	public EquipoAlumno (Alumno[] grupoAlumno) {
		super();
		this.grupoAlumno = new HashSet <>();
	}
	public EquipoAlumno (Alumno nombreEquipo, Collection<? extends Alumno> grupoAlumno) {
		super();
		this.nombreEquipo = (Alumno) nombreEquipo;
		this.grupoAlumno.addAll(grupoAlumno);
	}
	public void añadirAlumno(Alumno dni) {
		grupoAlumno.add(dni);
	}
	public void borrarAlumno(Alumno dni) {
		grupoAlumno.remove(dni);
	}
	public String esJugadorEquipo(Alumno dni) {
		boolean es_jugador=false;
		for (int i=0; i<grupoAlumno.size()-1; i++) {
			/*if(grupoAlumno(i)==dni) {
				
			}*/
		}
		return null;
	}
	public <Alumno> String listaEquipo () {
		return (String) grupoAlumno.toString();
	}
	public <Alumno> Equipo union (Equipo otro) {
		otro.union((Equipo) grupoAlumno);
		return otro;
	}
	public <Equipo> ArrayList interseccion (Collection<? extends Equipo> grupoAlumno, Equipo otro) {
		List <Equipo> listaJugadores= new ArrayList <> ();
		listaJugadores.addAll((Collection<? extends Equipo>) otro);
		for (Equipo i: listaJugadores) {
			if(!grupoAlumno.contains(i)) {
				listaJugadores.remove(i);	
			}
		}
		return (ArrayList) listaJugadores;
	}
}
