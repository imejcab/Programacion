/*package Ejercicio3Genericos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import EquiposDeportivos.Alumno;
import EquiposDeportivos.Equipo;

public class EquipoInteger <Integer>{
	private Integer nombreEquipo;
	private Set <Alumno> grupoAlumno;
	public EquipoInteger(Integer nombreEquipo, Set<Alumno> grupoAlumno) {
		super();
		this.nombreEquipo = nombreEquipo;
		this.grupoAlumno =  new HashSet ();
	}
	public EquipoInteger(String nombreEquipo) {
		super();
		this.nombreEquipo = (Integer) nombreEquipo;
	}
	public EquipoInteger(Alumno[] grupoAlumno) {
		super();
		this.grupoAlumno = new HashSet <>();
	}
	public EquipoInteger(String nombreEquipo, Collection<? extends Alumno> grupoAlumno) {
		super();
		this.nombreEquipo = (Integer) nombreEquipo;
		this.grupoAlumno.addAll(grupoAlumno);
	}
	public void añadirAlumno(Alumno dni) {
		grupoAlumno.add(dni);
	}
	public void borrarAlumno(Alumno dni) {
		grupoAlumno.remove(dni);
	}
	public String esJugadorEquipo(Alumno dni) {
		boolean es_jugador=false;
		for (int i=0; i<grupoAlumno.size()-1; i++) {
			/*if(grupoAlumno(i)==dni) {
				
			}*/
		/*}
		return null;
	}
	public <Integer> String listaEquipo () {
		return (String) grupoAlumno.toString();
	}
	public <Integer> Equipo union (Equipo otro) {
		otro.union((Equipo) grupoAlumno);
		return otro;
	}
	public <Equipo> ArrayList interseccion (Collection<? extends Equipo> grupoAlumno, Equipo otro) {
		List <Equipo> listaJugadores= new ArrayList <> ();
		List <Equipo> listaJugadoresUnidos= new ArrayList <> ();
		listaJugadores.addAll((Collection<? extends Equipo>) otro);
		for (Equipo i: listaJugadores) {
			if(!grupoAlumno.contains(i)) {
				listaJugadores.remove(i);	
			}
		}
		return (ArrayList) listaJugadores;
	}
	
}*/
