package GranAlmacen;
import java.util.Scanner;
public class MenuUI {
	public void gestionAlmacen() {
		Scanner sc= new Scanner(System.in);
		int opcion=1;
		Cliente andres=new Cliente();
		Cliente juan=new Cliente();
		Cliente mar=new Cliente();
		Caja a= new Caja();
		Caja b= new Caja();
		Caja c= new Caja();
		Almacen central= new Almacen();
		do {
			System.out.println("Dime una opcion \n opcion 1: Abrir caja \n Opcion 2: Cerrar Caja \n Opcion 3: Nuevo Cliente \n Opcion 4: Atender Cliente \n Opcion 5: Salir");
			opcion=Integer.valueOf(sc.nextLine());
		}while(opcion<1 && opcion>5);
		switch(opcion) {
		case 1:
			central.abrirCaja(opcion);
		case 2:
			central.cerrarCaja(opcion);
		case 3:
			b.addCliente(mar);
		case 4:
			a.atenderCliente();
		}
	}
}
