package GranAlmacen;

public class ExceptionAlmacen extends Exception {

	public ExceptionAlmacen() {
	}

	public ExceptionAlmacen(String message) {
		super(message);
	}

	public ExceptionAlmacen(Throwable cause) {
		super(cause);
	}

	public ExceptionAlmacen(String message, Throwable cause) {
		super(message, cause);
	}

	public ExceptionAlmacen(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
