package GranAlmacen;

import java.util.ArrayList;
import java.util.List;

public class Caja {
	private int numeroCaja;
	private List <Cliente> cliente;
	private boolean abierta;
	private static int secuencia;
	public Caja() {
		super();
		this.numeroCaja = secuencia ++;
		this.cliente = new ArrayList <>();
		this.abierta = false;
	}
	public boolean abrirCaja() throws ExceptionCaja {
		if(this.abierta==true) {
			throw new ExceptionCaja("La caja ya esta abierta");
		}
		this.abierta=true;
		return abierta;
	}
	public boolean cerrarCaja() throws ExceptionCaja {
		if(!abierta || !this.cliente.isEmpty()) {
			throw new ExceptionCaja("La caja no se puede cerrar");
		}
		abierta=false;
		return abierta;
	}
	public void addCliente(Cliente c) throws ExceptionCaja {
		if(c!=null && abierta) {
			this.cliente.add(c);
		}else {
			throw new ExceptionCaja("No se puede añadir el cliente indicado");
		}
	}
	public String atenderCliente() throws ExceptionCaja {
		if(!abierta || this.cliente.isEmpty()) {
			throw new ExceptionCaja("No se puede atender al cliente");
		}
		Cliente clienteAtendido= this.cliente.remove(0);
		return String.format("Se ha atendido al cliente " + clienteAtendido);
	}
	public int compareTo(Caja o) {
		return this.cliente.size()==o.cliente.size()?this.numeroCaja-o.numeroCaja:this.cliente.size()- o.cliente.size();
	}
	public int getNumeroCaja() {
		return numeroCaja;
	}
	public boolean isAbierta() {
		return abierta;
	}
}
