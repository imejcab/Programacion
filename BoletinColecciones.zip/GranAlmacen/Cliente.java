package GranAlmacen;

public class Cliente {
	private int codigoCliente;
	private static int secuencia;
	public Cliente() {
		super();
		this.codigoCliente = secuencia++;
	}
	public String toString() {
		return String.format("Cliente [codigoCliente=" + codigoCliente + "]");
	}
}
