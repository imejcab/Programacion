package GranAlmacen;

import java.util.Arrays;
import java.util.List;

public class Almacen {
	public static final int NUMEROMAXCAJAS=20;	
	private Caja[] cajas;
	public Almacen() {
		super();
		for(int i=0;i<NUMEROMAXCAJAS; i++) {
			cajas [i]=new Caja (i+1);
		}
	}
	private Caja obtenerCajaPrioritaria() {
		Arrays.sort(cajas);
		return this.cajas[0];
	}
	public boolean abrirCaja(int id) {
		boolean abrirAhora=false;
		for (Caja abrir: cajas) {
			if(abrir.getNumeroCaja()==id && abrir.isAbierta()==false) {
				abrirAhora=true;
			}
		}
		return abrirAhora;
	}
	public boolean cerrarCaja(int id) {
		boolean cerrarAhora=false;
		for (Caja cerrar: cajas) {
			if(cerrar.getNumeroCaja()==id && cerrar.isAbierta()==true) {
				cerrarAhora=true;
			}
		}
		return cerrarAhora;
	}
	public String asignarClienteCaja() {
		Caja cajaPrioritaria=obtenerCajaPrioritaria();
		Cliente c=new Cliente();
		cajaPrioritaria.addCliente(c);;
		return String.format("Es usted el cliente numero xx y debe ir a la \n" + "caja numero xx", c, cajaPrioritaria.getNumeroCaja());
	}
}
