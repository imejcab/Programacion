package GranAlmacen;

public class ExceptionCaja extends Exception {

	public ExceptionCaja() {
	}

	public ExceptionCaja(String message) {
		super(message);
	}

	public ExceptionCaja(Throwable cause) {
		super(cause);
	}

	public ExceptionCaja(String message, Throwable cause) {
		super(message, cause);
	}

	public ExceptionCaja(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
