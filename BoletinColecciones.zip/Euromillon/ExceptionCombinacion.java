package Euromillon;

public class ExceptionCombinacion extends Exception {

	public ExceptionCombinacion() {
	}

	public ExceptionCombinacion(String message) {
		super(message);
	}
	public ExceptionCombinacion(String message, Throwable cause) {
		super(message, cause);
	}
}
