package Euromillon.TestEuromillon;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import Euromillon.Combinacion;
import Euromillon.ExceptionCombinacion;
import Euromillon.ExceptionHistorial;
import Euromillon.Historial;

class TestEuromillon {

	@Test
	void testCombinacionErronea() {
		try {
			Combinacion e= new Combinacion(3,3,5,6,7,8,9);
			assert(false);
		} catch (ExceptionCombinacion e) {
			assert(true);
		}
	}
	@Test
	void testCombinacionValida() {
		try {
			Combinacion e= new Combinacion(3,4,5,6,7,8,9);
		} catch (ExceptionCombinacion e) {
			assert(false);
		}
	}
	@Test
	void testAddSorteoLocalDateCombinacion() throws ExceptionHistorial, ExceptionCombinacion {
		try {
			Combinacion e= new Combinacion(3,4,5,6,7,8,9);
		} catch (ExceptionCombinacion e) {
			assert(false);
		}
		Historial a= new Historial();
		Combinacion e= new Combinacion(3,4,5,6,7,8,9);
		assertTrue(a.addSorteo(LocalDate.now().minusDays(5), e));
	}

	@Test
	void testAddSorteoIntIntIntCombinacion() throws ExceptionCombinacion, ExceptionHistorial {
		try {
			Combinacion e= new Combinacion(3,4,5,6,7,8,9);
		} catch (ExceptionCombinacion e) {
			assert(false);
		}
		Historial a= new Historial();
		Combinacion e= new Combinacion(3,4,5,6,7,8,9);
		assertTrue(a.addSorteo(2002, 3, 3, e));
	}
	@Test
	void testModificarSorteoLocalDateCombinacionValido() throws ExceptionCombinacion {
		try {
			Combinacion e= new Combinacion(3,3,5,6,7,8,9);
			assert(false);
		} catch (ExceptionCombinacion e) {
			assert(true);
		}
		Historial a= new Historial();
		Combinacion e= new Combinacion(3,3,5,6,7,8,9);
		assertFalse(a.modificarSorteo(2052, 3, 3, e));
	}

	@Test
	void testModificarSorteoIntIntIntCombinacion() throws ExceptionCombinacion {
		try {
			Combinacion e= new Combinacion(3,3,5,6,7,8,9);
			assert(false);
		} catch (ExceptionCombinacion e) {
			assert(true);
		}
		Historial a= new Historial();
		Combinacion e= new Combinacion(3,3,5,6,7,8,9);
		assertTrue(a.modificarSorteo(2010, 8, 23, e));
	}

	@Test
	void testBorrarSorteo() throws ExceptionHistorial {
		try {
			Combinacion e= new Combinacion(3,3,5,6,7,8,9);
			assert(false);
		} catch (ExceptionCombinacion e) {
			assert(true);
		}
		Historial a= new Historial();
		assertTrue(a.BorrarSorteo(LocalDate.now()));
	}
	void testBorrarSorteoParametrizado(String cadenas) throws ExceptionHistorial {
		try {
			Combinacion e= new Combinacion(3,3,5,6,7,8,9);
			assert(false);
		} catch (ExceptionCombinacion e) {
			assert(true);
		}
		Historial a= new Historial();
		assertTrue(a.BorrarSorteo(LocalDate.now()));
	}
	@Test
	void testListarSorteosDesdeFecha() {
		fail("Not yet implemented");
	}

	@Test
	void testMostrarHistorico() {
		Historial a= new Historial();
		assertFalse(a.mostrarHistorico().isEmpty());
		assertTrue(a.mostrarHistorico().contains("casa"));
	}
	@ParameterizedTest
	@ValueSource(strings= {"hola","Buenas","job"})
	void testMostrarHistoricoParametrizado(String cadenas) {
		Historial a= new Historial();
		assertTrue(a.mostrarHistorico().contains(cadenas));
	}
	@Test
	void testComprobarAciertos() {
		fail("Not yet implemented");
	}

}
