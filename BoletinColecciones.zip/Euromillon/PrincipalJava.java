package Euromillon;

public class PrincipalJava {
	public static void main(String [] args) throws ExceptionCombinacion {
		new MenuUI().GestionSorteo();
	}
}
