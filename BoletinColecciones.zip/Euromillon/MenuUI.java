package Euromillon;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MenuUI {
	public void GestionSorteo() throws ExceptionCombinacion{
		Set <Integer> numeros= new HashSet <> ();
		Set <Integer> estrellas= new HashSet <> ();
		Combinacion a = new Combinacion(2,3,6,23,32,3,7);
		Historial e= new Historial();
		a.comprobarAciertos(a);
		try {
			e.addSorteo(LocalDate.now(), a);
		} catch (ExceptionHistorial e1) {
			e1.printStackTrace();
		}
		try {
			e.addSorteo(2000, 12, 3, a);
		} catch (ExceptionHistorial e1) {
			e1.printStackTrace();
		}
		try {
			e.BorrarSorteo(LocalDate.of(2002, 3, 2));
		} catch (ExceptionHistorial e1) {
			e1.printStackTrace();
		}
		System.out.println(e.listarSorteosDesdeFecha(LocalDate.now()));
		try {
			e.modificarSorteo(LocalDate.of(2020, 5, 7), a);
		} catch (ExceptionHistorial e1) {
			e1.printStackTrace();
		}
		System.out.println(e.mostrarHistorico());
	}
}
