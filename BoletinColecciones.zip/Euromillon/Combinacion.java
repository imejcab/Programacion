package Euromillon;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
public class Combinacion {
	private static final int VALORMINIMO=1;
	private static final int VALORMAXIMONUMEROS=50;
	private static final int VALORMAXIMOESTRELLAS=12;
	private static final int TOTALNUMEROS=5;
	private static final int TOTALESTRELLAS=2;
	Set <Integer> numeros;
	Set <Integer> estrellas;
	public Combinacion(Integer [] numeros, Integer [] estrellas) {
		super();
		if(numeros.length==TOTALNUMEROS || estrellas.length==TOTALESTRELLAS) {
			this.numeros = new HashSet <> ();
			this.estrellas = new HashSet <> ();
		}
	}
	public static Integer[] toArrayEnteros (Integer ... enteros) {
		return enteros;
	}
	public Combinacion(int num1, int num2, int num3, int num4, int num5, int star1, int star2) throws ExceptionCombinacion {
		this(toArrayEnteros(num1, num2, num3, num4, num5), toArrayEnteros(star1, star2));
		if((num1>VALORMINIMO && num2>VALORMINIMO && num3>VALORMINIMO && num4>VALORMINIMO && num5>VALORMINIMO && star1>VALORMINIMO && star2> VALORMINIMO) && (num1<VALORMAXIMONUMEROS && num2<VALORMAXIMONUMEROS && num3<VALORMAXIMONUMEROS && num4<VALORMAXIMONUMEROS && num5<VALORMAXIMONUMEROS && star1<VALORMAXIMOESTRELLAS && star2<VALORMAXIMOESTRELLAS)) {
		}
		numeros=new HashSet <> ();
		numeros.add(num1);
		numeros.add(num2);
		numeros.add(num3);
		numeros.add(num4);
		numeros.add(num5);
		estrellas=new HashSet <> ();
		estrellas.add(star1);
		estrellas.add(star2);
		validarDatos ();
	}
	public void validarDatos() throws ExceptionCombinacion {
		if(numeros.size()<VALORMAXIMONUMEROS) {
			throw new ExceptionCombinacion("Hay elementos repetidos");
		}
		if(estrellas.size()<VALORMAXIMOESTRELLAS) {
			throw new ExceptionCombinacion("Hay elementos repetidos");
		}
		for (int n: numeros) {
			if(n>VALORMAXIMONUMEROS || n<VALORMINIMO) {
				throw new ExceptionCombinacion("El valor de numeros no es valido");
			}
		}
	}
	public Set<Integer> getNumeros() {
		return numeros;
	}
	public Set<Integer> getEstrellas() {
		return estrellas;
	}
	public int hashCode() {
		return Objects.hash(estrellas, numeros);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Combinacion other = (Combinacion) obj;
		if(Objects.equals(estrellas, other.estrellas) && Objects.equals(numeros, other.numeros)) {
			resultado=true;
		}
		return resultado;
	}
	public String toString() {
		return String.format("La combinacion ganadora en el sorteo es" + numeros + estrellas + "]");
	}
	public int comprobarAciertos(Combinacion e) {
		int coincidencias=0;
		
		for(int i:numeros) {
			if(e.getNumeros().contains(i)) {
				coincidencias++;
			}
		}
		for(int i:estrellas) {
			if(e.getEstrellas().contains(i)) {
				coincidencias++;
			}
		}
		return coincidencias;
		
	}
}
