package Euromillon;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Historial {
	Map <LocalDate, Combinacion> apuestaGanadora;
        //Claves (keyset), Valores
	public Historial() {
		super();
		this.apuestaGanadora = new HashMap <> ();
	}
	//Metodo para anadir una combinacion y fecha y establecer un sorteo del dia 
	public boolean addSorteo (LocalDate fecha, Combinacion e) throws ExceptionHistorial{
		boolean esAñadido=false;
		if(apuestaGanadora.containsKey(fecha)) {
			throw new ExceptionHistorial("Este sorteo ya existe, no podemos añadir");
		}
			apuestaGanadora.put(fecha, e);
		return true;
	}
	//Metodo para anadir una combinacion y fecha con formato anio, mes, dia y establecer un sorteo del dia 
	public boolean addSorteo(int anio, int mes, int dia, Combinacion e) throws ExceptionHistorial {
		boolean esAñadido=false;
		if(apuestaGanadora.containsKey(LocalDate.of(anio, mes, dia))) {
			throw new ExceptionHistorial("Este sorteo ya existe, no podemos añadir");
		}else {
			esAñadido=true;
			apuestaGanadora.put(LocalDate.of(anio, mes, dia), e);
		}
		return esAñadido;
	}
	//Metodo para modificar la combinacion de un dia fijado por parametro
	public boolean modificarSorteo(LocalDate fecha, Combinacion e) throws ExceptionHistorial {
		boolean esModificado=false;
		if(apuestaGanadora.containsKey(fecha)) {
			apuestaGanadora.put(fecha, e);
		}else {
			throw new ExceptionHistorial("Este sorteo no existe, no podemos modificar");
		}
		return esModificado;
	}
	public boolean modificarSorteo(int anio, int mes, int dia, Combinacion e) {
		boolean esModificado=false;
		if(apuestaGanadora.containsKey(LocalDate.of(anio, mes, dia))) {
			apuestaGanadora.put(LocalDate.of(anio, mes, dia), e);
		}
		return esModificado;
	}
	public boolean BorrarSorteo(LocalDate fecha) throws ExceptionHistorial {
		boolean esBorrado=false;
		if(apuestaGanadora.containsKey(fecha)) {
			apuestaGanadora.remove(fecha);
			esBorrado=true;
		}else {
			throw new ExceptionHistorial("El sorteo que deseamos buscar no existe");
		}
		return esBorrado;
	}
	public List <LocalDate> listarSorteosDesdeFecha(LocalDate fecha){
		List <LocalDate> fechas= new ArrayList <> ();
		/*Iterator <Entry<LocalDate,Combinacion>> it= this.apuestaGanadora.entrySet().iterator();
		while(it.hasNext()) {
			Entry<LocalDate, Combinacion> entrada =it.next();
			entrada.getKey();
			if(entrada.getKey().isAfter(fecha)) {
				fecha=entrada.getKey();
				fechas.add(fecha);
			}
		}*/
		for(LocalDate f: this.apuestaGanadora.keySet()) {
			if(f.isAfter(fecha)) {
				fechas.add(fecha);
			}
		}
		return fechas;
	}
	public String mostrarHistorico() {
		StringBuilder sb=new StringBuilder ();
		Iterator <Entry<LocalDate,Combinacion>> it= this.apuestaGanadora.entrySet().iterator();
		while(it.hasNext()) {
			Entry<LocalDate, Combinacion> entrada =it.next();
			entrada.getKey();
			sb.append(entrada);
		}
		return sb.toString();
	}
	public Map <String, Integer> comprobarAciertos(LocalDate fecha, Combinacion e) throws ExceptionHistorial{
		Map <String, Integer> aciertos=new HashMap <> ();
		if(!this.apuestaGanadora.containsKey(fecha)) {
			throw new ExceptionHistorial();
		}
		aciertos.put(fecha.format(DateTimeFormatter.ofPattern("mm-dd-yyyy")), this.apuestaGanadora.get(fecha).comprobarAciertos(e));
		return aciertos;
	}
	
}
