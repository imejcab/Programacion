package EquiposDeportivos;

public class ExceptionAlumno extends Exception {

	public ExceptionAlumno() {
	}

	public ExceptionAlumno(String message) {
		super(message);
	}

	public ExceptionAlumno(Throwable cause) {
		super(cause);
	}

	public ExceptionAlumno(String message, Throwable cause) {
		super(message, cause);
	}

	public ExceptionAlumno(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
