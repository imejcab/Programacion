package EquiposDeportivos;

import java.util.Objects;

public class Alumno {
	private String nombre;
	private String dni;
	private int edad;
	private char sexo;
	private String ciudad;
	public Alumno(String nombre, String dni) {
		super();
		this.nombre = nombre;
		this.dni = dni;
	}
	public Alumno(String nombre, String dni, int edad, char sexo, String ciudad) {
		super();
		this.nombre = nombre;
		this.dni = dni;
		this.edad = edad;
		this.sexo = sexo;
		this.ciudad = ciudad;
	}
	public char getSexo() {
		if(sexo=='M' && sexo=='H') {
			this.sexo=sexo;
		}
		return sexo;
	}
	public int getEdad() {
		return edad;
	}
	public String getDni() {
		return dni;
	}
	public String getCiudad() {
		return ciudad;
	}
	public String toString() {
		return String.format("Alumno [nombre=" + nombre + ", dni=" + dni + "]");
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Alumno other = (Alumno) obj;
		if(Objects.equals(dni, other.dni)) {
			resultado=true;
		}
		return resultado;
	}
}