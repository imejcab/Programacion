package EquiposDeportivos;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
public class PrincipalJava {
	public static void main(String [] args) {
		List <Alumno> alumnos =new ArrayList <>();
		alumnos.add(new Alumno("Ivan","27519865C"));
		alumnos.add(new Alumno("Mar","27519861C"));
		alumnos.add(new Alumno("Luz","27529865C"));
		alumnos.add(new Alumno("Juan","27515865C"));
		/*Set<Equipo> grupoFutbol = new HashSet <> ();*/
		Equipo a= new Equipo ("Leones");
		try {
			a.añadirAlumno(alumnos.get(0));
		} catch (ExceptionAlumno e) {
			e.printStackTrace();
		}
		try {
			a.añadirAlumno(alumnos.get(1));
		} catch (ExceptionAlumno e) {
			e.printStackTrace();
		}
		Equipo b =new Equipo ("Aguilas");
		try {
			a.añadirAlumno(alumnos.get(3));
		} catch (ExceptionAlumno e) {
			e.printStackTrace();
		}
		try {
			a.añadirAlumno(alumnos.get(2));
		} catch (ExceptionAlumno e) {
			e.printStackTrace();
		}
		b.listaEquipo();
		b.interseccion(a);
		a.union(b);
		/*grupoFutbol.add(new Equipo ("Perros"));*/
		try {
			a.borrarAlumno(alumnos.get(1));
		} catch (ExceptionAlumno e) {
			e.printStackTrace();
		}
	}
}
