package EquiposDeportivos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Equipo {
	private String nombreEquipo;
	private Set <Alumno> grupoAlumno;
	public Equipo(String nombreEquipo, Set<Alumno> grupoAlumno) {
		super();
		this.nombreEquipo = nombreEquipo;
		this.grupoAlumno =  new HashSet ();
	}
	public Equipo(String nombreEquipo) {
		super();
		this.nombreEquipo = nombreEquipo;
	}
	public Equipo(Alumno[] grupoAlumno) {
		super();
		this.grupoAlumno = new HashSet <>();
	}
	public Equipo(String nombreEquipo, Collection<? extends Alumno> grupoAlumno) {
		super();
		this.nombreEquipo = nombreEquipo;
		this.grupoAlumno.addAll(grupoAlumno);
	}
	public void añadirAlumno(Alumno dni) throws ExceptionAlumno {
		if(!grupoAlumno.contains(dni)) {
			this.grupoAlumno.add(dni);
		}else {
			throw new ExceptionAlumno("El alumno ya existe");
		}
	}
	public void borrarAlumno(Alumno dni) throws ExceptionAlumno {
		if(grupoAlumno.contains(dni)) {
			grupoAlumno.remove(dni);
		}else {
			throw new ExceptionAlumno("El alumno no existe");
		}
		/*Es lo mismo con iteradores fundamentales para desplazarse por un conjunto*/
		Iterator <Alumno> it=this.grupoAlumno.iterator();
		while(it.hasNext()) {
			if(it.next().equals(grupoAlumno)) {
				it.next();
			}
		}
	}
	public Alumno esJugadorEquipo(Alumno dni) {
		return this.grupoAlumno.contains(dni)?dni:null;
	}
	public <String> String listaEquipo () {
		/*return (String) grupoAlumno.toString();*/
		StringBuilder sb= new StringBuilder ();
		for (Alumno alumno : grupoAlumno) {
			sb.append(alumno);
		}
		return (String) sb.toString();
	}
	public <String> Equipo union (Equipo otro) {
		otro.union((Equipo) grupoAlumno);
		return otro;
	}
	public <Equipo> ArrayList interseccion (Equipo otro) {
		List <Equipo> listaJugadores= new ArrayList <> ();
		listaJugadores.addAll((Collection<? extends Equipo>) otro);
		for (Equipo i: listaJugadores) {
			if(!grupoAlumno.contains(i)) {
				listaJugadores.remove(i);	
			}
			/*retainAll devuelve los valores que coincidan de las dos listas*/ 
		}
		return (ArrayList) listaJugadores;
	}
	public String jugadoresMasculinoMayores() {
		StringBuilder sb= new StringBuilder();
		Map <Alumno, Alumno> mapear= new HashMap <> ();
		for (Alumno i: grupoAlumno) {
			if(i.getEdad()>17 && i.getSexo()=='M') {
				sb.append(i);
			}
		}
		return sb.toString();
	}
	public boolean equipoEsFemenino() {
		boolean esFemenino=true;
		for(Alumno i: grupoAlumno) {
			if(i.getSexo()=='M') {
				esFemenino=false;
			}
		}
		return esFemenino;
	}
	public int JugadorasFemeninas() {
		int contador=0;
		for(Alumno i: grupoAlumno) {
			if(i.getSexo()=='F' && i.getEdad()>17) {
				contador++;
			}
		}
		return contador;
	}
	public int edadMayor() {
		int edadMayor=0;
		for(Alumno i: grupoAlumno) {
			if(i.getEdad()>edadMayor) {
				edadMayor=i.getEdad();
			}
		}
		return edadMayor;
	}
	public String DNIJugadoresMayores() {
		StringBuilder sb= new StringBuilder();
		for(Alumno i: grupoAlumno) {
			if(i.getEdad()>17 && i.getSexo()=='M') {
				sb.append(i.getDni());
			}
		}
		return sb.toString();
	}
	public boolean hayJugadoraMayor() {
		boolean hayJugadoraMayor=false;
		for(Alumno i: grupoAlumno) {
			if(i.getSexo()=='F' && i.getEdad()>17) {
				hayJugadoraMayor=true;
			}
		}
		return hayJugadoraMayor;
	}
	public int contarCiudadesDiferentes() {
		Set <String> a= new HashSet <>();
		for(Alumno i: grupoAlumno) {
			a.add(i.getCiudad());
		}
		return a.size();
	}
}
