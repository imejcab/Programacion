package HistorialNavegacion;

public class ExceptionPagWeb extends Exception {

	public ExceptionPagWeb() {
	}

	public ExceptionPagWeb(String message) {
		super(message);
	}

	public ExceptionPagWeb(Throwable cause) {
		super(cause);
	}

	public ExceptionPagWeb(String message, Throwable cause) {
		super(message, cause);
	}

	public ExceptionPagWeb(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
