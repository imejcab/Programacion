package HistorialNavegacion;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
public class Historial {
	List <PaginaWeb> historial;
	public Historial() {
		super();
		this.historial = new ArrayList <> ();
	}
	public void anadirConsulta (PaginaWeb otra) throws Exception {
		if(this.historial.isEmpty() || otra.esPosterior(this.historial.get(this.historial.size()-1))) {
			this.historial.add(otra);
		}else {
			throw new Exception("La fecha de la ultima visita no es valida");
		}
	}
	public String consultarHistorial() {
		StringBuilder sb= new StringBuilder ();
		for(PaginaWeb historia: historial) {
			sb.append(historia);
		}
		return sb.toString();
	}
	public String ConsultarDia(LocalDateTime fechaHora) {
		StringBuilder sb= new StringBuilder();
		for(PaginaWeb historia: historial) {
			if(historia.getFechaHora().toLocalDate().equals(fechaHora)) {
				sb.append(historia);
			}
		}
		return sb.toString();
	}
	public void borrarHistorial() {
		historial.removeAll(this.historial);
	}
	public void borrarHistorialPagina(String url) throws Exception {
		boolean es_borrado=false;
		for(PaginaWeb registro: historial) {
			if(registro.equals(url)) {
				historial.remove(url);
				es_borrado=true;
			}
			if(es_borrado=false) {
				throw new Exception("Esa pagina no se encuentra en el historial");
			}
		}
	}
}
