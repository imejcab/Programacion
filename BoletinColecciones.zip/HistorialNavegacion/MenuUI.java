package HistorialNavegacion;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
public class MenuUI {
	public void gestionHistorial() throws Exception {
		Scanner sc=new Scanner(System.in);
		PaginaWeb telePink= new PaginaWeb ("sbsb78", LocalDateTime.now());
		PaginaWeb blogDigital= new PaginaWeb ("wfwy774", LocalDateTime.now());
		PaginaWeb natureVisual= new PaginaWeb ("hffw87", LocalDateTime.now());
		PaginaWeb redPasion= new PaginaWeb ("whbfw98", LocalDateTime.now());
		PaginaWeb PlanetConnect= new PaginaWeb ("anfwe884", LocalDateTime.now());
		Historial you= new Historial ();
		int opcion=1;
		while(opcion<6) {
			do {
				System.out.println("Dime que opcion prefieres \n 1- Nueva Pagina Consultada \n 2- Consultar Historial Completo \n 3- Consultar Historial de un dia \n 4- Borrar todo el historial \n 5- Borrar visitas de una pagina \n 6- Salir");
				opcion=Integer.valueOf(sc.nextLine());
			}while(opcion<1 || opcion>6);
			switch(opcion){
			case 1:
				System.out.println("Dime que pagina visitaste");
				String web= sc.nextLine();
				you.anadirConsulta(new PaginaWeb(web, LocalDateTime.now()));
				break;
			case 2:
				you.consultarHistorial();
				break;
			case 3:
				int anio;
				do {
					System.out.println("Dime un año ");
					anio=Integer.valueOf(sc.nextLine());
				}while(anio<1 || anio>LocalDateTime.now().getYear());
				int mes;
				do {
					System.out.println("Dime un mes ");
					mes=Integer.valueOf(sc.nextLine());
				}while(mes<1  || mes>12);
				int dia;
				do {
					System.out.println("Dime un dia ");
					dia=Integer.valueOf(sc.nextLine());
				}while(dia<1 && dia>31);
				you.ConsultarDia(LocalDateTime.of(anio, mes, dia,0,0));
				break;
			case 4:
				you.borrarHistorial();
				break;
			case 5:
				System.out.println("Dime que pagina web quieres borrar las visitas");
				String webDelete=sc.nextLine();
				try {
					you.borrarHistorialPagina(webDelete);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			}
		}
	}
}
