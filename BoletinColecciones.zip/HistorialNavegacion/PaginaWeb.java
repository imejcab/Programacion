package HistorialNavegacion;
import java.time.LocalDateTime;
import java.util.Objects;
public class PaginaWeb {
	private String url;
	private LocalDateTime fechaHora;
	public PaginaWeb(String url) {
		super();
		this.url = url;
	}
	public PaginaWeb(String url, LocalDateTime fechaHora) {
		super();
		this.url = url;
		this.fechaHora = LocalDateTime.now();
	}
	public String getUrl() {
		return url;
	}
	public LocalDateTime getFechaHora() {
		return fechaHora;
	}
	public int hashCode() {
		return Objects.hash(fechaHora, url);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		PaginaWeb other = (PaginaWeb) obj;
		if(Objects.equals(fechaHora, other.fechaHora) && Objects.equals(url, other.url)) {
			resultado=true;
		}
		return resultado;
	}
	public String toString() {
		return String.format("PaginaWeb [url=" + url + ", fechaHora=" + fechaHora + "]");
	}
	public boolean esPosterior(PaginaWeb otra) {
		boolean esPosterior=false;
		if(otra.fechaHora.isBefore(this.fechaHora)) {
			esPosterior=true;
		}
		return esPosterior;
	}
}
