package Reserse;
public interface reverse {
	public static <T> T[] reverse (T[] listaNumeros) {
		T[] inverso=listaNumeros.clone();
		for (int i=0; i<listaNumeros.length;i++) {
			inverso [i]=listaNumeros[listaNumeros.length -1];
		}
		return inverso;
	}
}