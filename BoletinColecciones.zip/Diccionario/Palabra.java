package Diccionario;

import java.util.ArrayList;
import java.util.List;

public class Palabra {
	private String nombre;
	private List <String> significados;
	public Palabra(String nombre, List<String> significados) {
		super();
		this.nombre = nombre;
		this.significados = new ArrayList <> ();
	}
	public String getNombre() {
		return nombre;
	}
}
