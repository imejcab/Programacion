package Diccionario;

public class PrincipalJava {
	public static void main (String [] args) {
		new MenuUI().GestionDiccionario();
	}
}
