package Diccionario;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class PalabrasDiccionario {
	private Map <String, Collection <String>> palabras;
	public PalabrasDiccionario() {
		super();
		this.palabras = new HashMap <> ();
	}
	public void anadirPalabra(String e, String a) throws Exception {
		if(palabras.containsKey(e)) {
			if(palabras.containsKey(a)) {
				throw new Exception("Ese significado ya existe");
			}else {
				palabras.get(e).add(a);
			}
		}else {
			palabras.put(e, new HashSet <> ());
		}
	}
	public String buscarPalabra(String palabraBuscada) {
		StringBuilder sb= new StringBuilder();
		if(palabras.containsKey(palabraBuscada)) {
			sb.append(palabras.get(palabraBuscada).toString());
		}
		return sb.toString();
	}
	public void borrarPalabra(String palabra) {
		if(palabras.containsKey(palabra)) {
			palabras.get(palabra).remove(palabra);
		}
	}
	public String listarPalabra(String letras) {
		StringBuilder sb=new StringBuilder ();
		Iterator <Entry<String, Collection <String>>> it = this.palabras.entrySet().iterator();
		while(it.hasNext()) {
			Entry<String, Collection <String>> entrada =it.next();
			entrada.getKey();
			if(entrada.getKey().startsWith(letras)) {
				sb.append(entrada.getKey());
			}
		}
		return sb.toString();
	}
}
