package Diccionario;
import java.util.Scanner;
public class MenuUI {
	public void GestionDiccionario() {
		Scanner sc=new Scanner(System.in);
		int opcion=1;
		PalabrasDiccionario espanol= new PalabrasDiccionario ();
		while(opcion>0 && opcion<5) {
			do {
				System.out.println("Dime que opcion de menu quieres \n Opcion 1 - Añadir palabra \n 2- Buscar Palabra \n 3- Borrar palabra \n 4- Listar palabra ");
				opcion= Integer.valueOf(sc.nextLine());
			}while(opcion<1 || opcion>5);
			switch(opcion) {
			case 1:
				String palabra;
				String significado;
				String letra;
				do {
					System.out.println("Dime una palabra");
					 palabra= sc.nextLine();
				}while(palabra.length()==0);
				do {
					System.out.println("Dime un significado");
					significado= sc.nextLine();
				}while(significado.length()==0);
				try {
					espanol.anadirPalabra(palabra, significado);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case 2:
				do {
					System.out.println("Dime una palabra");
					 palabra= sc.nextLine();
				}while(palabra.length()==0);
				System.out.println(espanol.buscarPalabra(palabra));
				break;
			case 3:
				do {
					System.out.println("Dime una palabra");
					 palabra= sc.nextLine();
				}while(palabra.length()==0);
				espanol.borrarPalabra(palabra);
				break;
			case 4:
				do {
					System.out.println("Dime unas letras");
					 letra= sc.nextLine();
				}while(letra.length()==0);
				System.out.println(espanol.listarPalabra(letra));
				break;
			}
		}
	}
}
