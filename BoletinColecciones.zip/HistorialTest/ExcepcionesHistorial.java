package HistorialTest;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import HistorialNavegacion.Historial;
import HistorialNavegacion.PaginaWeb;

class ExcepcionesHistorial {
	@Test
	void testAnadirConsulta() {
		PaginaWeb nueva= new PaginaWeb ("yahoo.es", LocalDateTime.now().plusDays(0));
		PaginaWeb antigua= new PaginaWeb ("google.es", LocalDateTime.now().plusDays(1));
		Historial historial= new Historial();
		try {
			historial.anadirConsulta(nueva);
			historial.anadirConsulta(antigua);
		}catch (Exception c) {
			assert(false);
		}
	}
	@Test
	void testAnadirConsultaNoOrden() {
		PaginaWeb nueva= new PaginaWeb ("yahoo.es", LocalDateTime.now().plusDays(0));
		PaginaWeb antigua= new PaginaWeb ("google.es", LocalDateTime.now().plusDays(0));
		Historial historial= new Historial();
		assertThrows(Exception.class,() ->{
			historial.anadirConsulta(nueva);
			historial.anadirConsulta(antigua);
		});
	}
	/*test*/
	/*void testAddPagina() {
		assertThrows(Exception.class, () -> { h.anadirConsulta(web);}, "ha habido un error");
	}
	void consultarHistorialOK() {
		assertEquals ("sbsb78", h.consultarHistorial());
	void consultarHistorialKO() {
		assertNotEquals ("sbsb78", h.consultarHistorial());
	}*/
	@Test
	void testConsultarHistorial() {
		Historial sas= new Historial();
		PaginaWeb nueva= new PaginaWeb ("yahoo.es", LocalDateTime.now().plusDays(0));
		try {
			sas.anadirConsulta(nueva);
		}catch (Exception c) {
			assert(false);
		}
		sas.borrarHistorial();
		assertTrue(sas.consultarHistorial().isEmpty());
		assertFalse(sas.consultarHistorial().isEmpty());
	}
	@Test
	void testConsultarDia() {
		Historial sas= new Historial();
		PaginaWeb nueva= new PaginaWeb ("yahoo.es", LocalDateTime.now().plusDays(0));
		try{
			sas.anadirConsulta(nueva);;
		}catch (Exception c) {
			assert(false);
		}
		assertTrue(sas.ConsultarDia(LocalDateTime.now()).isEmpty());
		assertFalse(sas.ConsultarDia(LocalDateTime.now().plusDays(0)).isEmpty());
	}
	void testBorrarHistorial2() {
		assertThrows(Exception.class, () -> { 
			testBorrarHistorial ();}, "Ha habido un error");
		}
	@Test
	void testBorrarHistorial() {
		Historial sas= new Historial();
		try {
			sas.anadirConsulta(new PaginaWeb ("yahoo.es", LocalDateTime.now().plusDays(0)));
			sas.anadirConsulta(new PaginaWeb ("google.es", LocalDateTime.now().plusDays(1)));
		}catch (Exception c) {Historial sas1= new Historial();
			assert(false);
		}
		assertTrue(sas.consultarHistorial().contains("yahoo.es"));
		sas.borrarHistorial();
		assertTrue(sas.consultarHistorial().contains("yahoo.es"));
		assertFalse(sas.consultarHistorial().contains("google.es"));
	}

	@Test
	void testBorrarHistorialPagina() throws Exception {
		Historial sas= new Historial();
		try {
			sas.anadirConsulta(new PaginaWeb ("yahoo.es", LocalDateTime.now().plusDays(0)));
			sas.anadirConsulta(new PaginaWeb ("google.es", LocalDateTime.now().plusDays(1)));
		}catch (Exception c) {
			assert(false);
		}
		assertTrue(sas.consultarHistorial().contains("yahoo.es"));
		sas.borrarHistorialPagina("yahoo.es");
		assertTrue(sas.consultarHistorial().contains("yahoo.es"));
		assertFalse(sas.consultarHistorial().contains("google.es"));
	}
}
