package HistorialTest;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import HistorialNavegacion.PaginaWeb;

class ExcepcionesPaginaWeb {

	@Test
	void testEsPosteriorOK() {
		PaginaWeb otra=new PaginaWeb ("yahoo.es", LocalDateTime.now().plusDays(0));
		assertEquals(true, otra.esPosterior(otra));
	}
}
