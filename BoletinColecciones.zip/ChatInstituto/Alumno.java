package ChatInstituto;

public class Alumno extends Persona {
	public Alumno(String nombre, int edad) throws ExceptionAlumno {
		super(nombre, edad);
		if(edad>4 && edad<18) {
			this.edad=edad;
		}else {
			throw new ExceptionAlumno("Edad no valida");
		}
	}
}
