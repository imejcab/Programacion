package ChatInstituto;

public class ExceptionChat extends Exception {

	public ExceptionChat() {
	}

	public ExceptionChat(String message) {
		super(message);
	}

	public ExceptionChat(Throwable cause) {
		super(cause);
	}

	public ExceptionChat(String message, Throwable cause) {
		super(message, cause);
	}

	public ExceptionChat(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
