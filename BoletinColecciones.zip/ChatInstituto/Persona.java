package ChatInstituto;

import java.util.Objects;

public abstract class Persona {
	private String nombre;
	protected int edad;
	public Persona(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}
	public int hashCode() {
		return Objects.hash(edad, nombre);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado= true;
		}else if (obj == null) {
			resultado= false;
		}else if (getClass() != obj.getClass()) {
			resultado= false;
		}
		Persona other = (Persona) obj;
		if(edad == other.edad && Objects.equals(nombre, other.nombre)) {
			resultado=true;
		}
		return resultado;
	}
	
}
