package ChatInstituto.TestChatInstituto;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import ChatInstituto.Alumno;
import ChatInstituto.Chat;
import ChatInstituto.ExceptionAlumno;
import ChatInstituto.ExceptionChat;
import ChatInstituto.ExceptionProfesor;
import ChatInstituto.Profesor;

class TestChat {

	@Test
	void testEnviarMensaje() {
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", 10);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, "que tal");
		}catch (ExceptionChat | ExceptionProfesor | ExceptionAlumno b) {
			assert(false);
		} 
	}

	@Test
	void testLeerMensajes() {
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", 10);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, "you");
		}catch (ExceptionChat| ExceptionProfesor | ExceptionAlumno  e) {
			assert(false);
		}
		assertEquals("Mensaje 1 de Juan Hola 17/08/1999 ", insti.leerMensajes());
		assertTrue(insti.leerMensajes().isEmpty());
		assertFalse(insti.leerMensajes().contains("hi"));
	}

	@Test
	void testLeerMensajesOrdenados() {
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", 10);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, "you");
		}catch (ExceptionChat| ExceptionProfesor | ExceptionAlumno  e) {
			assert(false);
		}
		assertEquals("Mensaje 1 de Juan Hola 17/08/1999 ", insti.leerMensajesOrdenados());
		assertTrue(insti.leerMensajesOrdenados().isEmpty());
		assertFalse(insti.leerMensajesOrdenados().contains("hi"));
	}

	@Test
	void testBorrarMensaje(){
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", 10);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, "you");
		}catch (Exception e) {
			assert(false);
		}
		assertThrows (Exception.class, () -> {
			insti.borrarMensaje(4);
		});
	}

	@Test
	void testMostrarMensaje() {
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", 10);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, "you");
		}catch (ExceptionChat | ExceptionProfesor | ExceptionAlumno b) {
			assert(false);
		}
		assertThrows (Exception.class, () -> {
			insti.mostrarMensaje("buenos dias");
		});
	}
	@ParameterizedTest
	@ValueSource(strings ={"Hola", "Adios"})
	void testEnviarMensajeParametrizado(String texto) {
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", 10);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, texto);
		}catch (ExceptionChat | ExceptionProfesor | ExceptionAlumno b) {
			assert(false);
		} 
	}

	@ParameterizedTest
	@CsvSource({"3,hola", "23,buenas","50,tardes"})
	void testLeerMensajesParametrizado(int edad, String texto) {
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", edad);
			Profesor quique= new Profesor ("quique", edad);
			insti.enviarMensaje(ana, quique, texto);
		}catch (ExceptionChat| ExceptionProfesor | ExceptionAlumno  e) {
			assert(false);
		}
		assertEquals("Mensaje 1 de Juan Hola 17/08/1999 ", insti.leerMensajes());
		assertTrue(insti.leerMensajes().isEmpty());
		assertFalse(insti.leerMensajes().contains("hi"));
	}

	@ParameterizedTest//Terminar  
	@CsvSource({"luis,23", "ana,25","carla,45"})
	void testLeerMensajesOrdenadosParametrizado(String nombre, int edad) {
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", 10);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, "you");
		}catch (ExceptionChat| ExceptionProfesor | ExceptionAlumno  e) {
			assert(false);
		}
		assertEquals("Mensaje 1 de Juan Hola 17/08/1999 ", insti.leerMensajesOrdenados());
		assertTrue(insti.leerMensajesOrdenados().isEmpty());
		assertFalse(insti.leerMensajesOrdenados().contains("hi"));
	}

	@ParameterizedTest
	@CsvSource({"12,3,hi", "5,23,Dias","50,11,Soleado"})
	void testBorrarMensajeParametrizado(int edad, int numeroMensaje, String texto){
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", edad);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, texto);
		}catch (Exception e) {
			assert(false);
		}
		assertThrows (Exception.class, () -> {
			insti.borrarMensaje(numeroMensaje);
		});
	}

	@ParameterizedTest
	@ValueSource(strings ={"Hola", "Adios"})
	void testMostrarMensajeParametrizado(String cadenas) {
		Chat insti = new Chat ();
		try {
			Alumno ana= new Alumno ("ana", 10);
			Profesor quique= new Profesor ("quique", 21);
			insti.enviarMensaje(ana, quique, "you");
		}catch (ExceptionChat | ExceptionProfesor | ExceptionAlumno b) {
			assert(false);
		}
		assertThrows (Exception.class, () -> {
			insti.mostrarMensaje(cadenas);
		});
	}
}
