package ChatInstituto;

public class Profesor extends Persona {
	public Profesor(String nombre, int edad) throws ExceptionProfesor {
		super(nombre, edad);
		if(edad>17 && edad<67) {
			this.edad=edad;
		}else {
			throw new ExceptionProfesor("Edad no valida");
		}
	}
}
