package ChatInstituto;
import java.time.LocalDateTime;
import java.util.Scanner;
public class MenuUI {
	public void gestionMensajes() throws Exception {
		try {
			Alumno javi= new Alumno ("javi", 15);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Profesor marta= new Profesor ("marta", 38);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Alumno ana= new Alumno ("ana", 10);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Profesor quique= new Profesor ("quique", 21);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Alumno javi= new Alumno ("javi", 15);
		Profesor marta= new Profesor ("marta", 38);
		Alumno ana= new Alumno ("ana", 10);
		Profesor quique= new Profesor ("quique", 21);
		Chat insti = new Chat ();
		insti.enviarMensaje(ana, quique, "Buenos dias");
		System.out.println(insti.leerMensajes());
		System.out.println(insti.leerMensajesOrdenados());
		insti.borrarMensaje(6);
		System.out.println(insti.mostrarMensaje("hola"));
	}
}
