package ChatInstituto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Mensaje {
	private Persona remitente;
	private String texto;
	private LocalDateTime fechaHora;
	public Mensaje(Persona remitente, String texto, LocalDateTime fechaHora) {
		super();
		this.remitente = remitente;
		this.texto = texto;
		this.fechaHora = fechaHora;
	}
	public Persona getRemitente() {
		return remitente;
	}
	public String getTexto() {
		return texto;
	}
	public LocalDateTime getFechaHora() {
		return fechaHora;
	}
	public int compareTo(Mensaje otro) {
		int resultado=0;
		if(otro.getRemitente().equals(this.remitente)) {
			resultado=0;
		}else if(otro.getRemitente().equals(null) || this.getRemitente().equals(null)) {
			resultado=1;
		}else {
			resultado=-1;
		}
		return resultado;
	}
	public int hashCode() {
		return Objects.hash(fechaHora, remitente, texto);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Mensaje other = (Mensaje) obj;
		if(Objects.equals(fechaHora, other.fechaHora) && Objects.equals(remitente, other.remitente)
				&& Objects.equals(texto, other.texto)) {
			resultado=true;
		}
		return resultado;
	}
	
}
