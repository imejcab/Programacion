package ChatInstituto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Chat {
	private List <Mensaje> chat;
	public Chat() {
		super();
		this.chat=new ArrayList <> () ;
	}
	public void enviarMensaje(Persona remitente, Persona nombre, String texto) throws ExceptionChat {
		if(remitente.edad<18 && nombre.edad<18) {
			throw new ExceptionChat("Un alumno menor de edad no puede enviar mensaje a un alumno");
		}
		chat.add(new Mensaje(remitente, texto, LocalDateTime.now()));
	}
	public String leerMensajes() {
		StringBuilder sb= new StringBuilder();
		int contador=1;
		for(Mensaje mensaje: chat) {
			sb.append("Mensaje " + contador + ":De :").append(mensaje);
			contador++;
		}
		return sb.toString();
	}
	public String leerMensajesOrdenados() {
		StringBuilder sb= new StringBuilder();
		for (Mensaje mensaje : chat) {
			sb.append(mensaje.compareTo(chat.get(chat.size()-1)));
		}
		return sb.toString();
	}
	public void borrarMensaje(int numeroMensaje) throws Exception {
		if(chat.get(numeroMensaje)==null) {
			throw new Exception ("No existe ese numero de mensaje");
		}
		chat.remove(numeroMensaje);
	}
	public String mostrarMensaje(String frase) throws Exception {
		if(!chat.contains(frase)) {
			throw new Exception ("No existe ninguna frase con esa frase");
		}
		StringBuilder sb= new StringBuilder();
		Iterator <Mensaje> it= this.chat.iterator();
		while(it.hasNext()) {
			if(chat.contains(frase)) {
				it.next();
				sb.append(it);
			}
		}
		return sb.toString();
	}
}
