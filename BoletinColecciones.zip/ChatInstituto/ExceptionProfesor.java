package ChatInstituto;

public class ExceptionProfesor extends Exception {

	public ExceptionProfesor() {
	}

	public ExceptionProfesor(String message) {
		super(message);
	}

	public ExceptionProfesor(Throwable cause) {
		super(cause);
	}

	public ExceptionProfesor(String message, Throwable cause) {
		super(message, cause);
	}

	public ExceptionProfesor(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
