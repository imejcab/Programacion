package Colecciones;

public class Genericos <k, v> {
	private k nombre;
	private v edad;
	public Genericos(k nombre, v edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}
	public String ToString() {
		return String.format("El nombre " + nombre + " y la edad " + edad);
	}
}
