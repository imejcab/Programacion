package Colecciones;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
public class Mapas {
	public static void main (String [] args) {
		Map<String, Collection <String>> carnet= new HashMap <>();
		carnet.put("Ivan", new HashSet <> ());
		carnet.put("Juan", new HashSet <> ());
		carnet.put("Ryan", new HashSet <> ());
		System.out.println(carnet.get("Ivan").add("471437535"));
		System.out.println(carnet.get("Ivan").add("471488535"));
		System.out.println(carnet.get("Juan").add("471400035"));
		System.out.println(carnet.get("Juan").add("499437535"));
		System.out.println(carnet.values());
		System.out.println(carnet.keySet());
		System.out.println(carnet.containsKey("471488535"));
	}
}
