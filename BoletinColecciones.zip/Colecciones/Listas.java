package Colecciones;
import java.util.ArrayList;
import java.util.List;
public class Listas {
	public static void main(String [] args) {
		List<String> listaNumeros= new ArrayList <>();
		listaNumeros.add("Ivan");
		listaNumeros.add("Javier");
		listaNumeros.add("Lucas");
		listaNumeros.add("Ivann");
	}
}
