package Colecciones;
import java.util.HashSet;
import java.util.Set;


public class Conjuntos {
	public static void main(String [] args) {
			Set<String> conjuntoNumeros= new HashSet<String>();
			conjuntoNumeros.add("Ivan");
			conjuntoNumeros.add("Javier");
			conjuntoNumeros.add("Lucas");
			conjuntoNumeros.add("Ivan");
	}
}

