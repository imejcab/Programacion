'''Escribe una función que, dada una lista de nombres y una letra, devuelva una lista
con todos los nombres que empiezan por dicha letra. Debe validar los datos.'''
#MODO EASY
lista=["Luis","Laura","Ana","Carlos","Adrian","Yoel"]
lista1=[]
letra="A"
nombres=lista[0:]
for i in nombres:
    if(i[0]==letra):
        lista1.append(i)
print(lista1)
#SEGUN REQUISITOS DEL EJERCICIO
lista2=[]
lista3=[]
nombress=str(input("Dime nombres y una letra para finalizar")).upper()
lista2.append(nombress)
while(len(nombress)>1):
    nombress=str(input("Dime nombres y una letra para finalizar")).upper()
    lista2.append(nombress)
print(lista2)
nombre=lista2[0:-1]
letra=lista2[-1]
for i in nombre:
    if(i[0]==letra):
        lista3.append(i)
print(f"La lista {lista3} empieza por la letra {letra}")
'''Escribe una función que, dada una lista de cadenas, devuelva la cadena más larga.
Si dos o más cadenas miden lo mismo y son las más largas, la función devolverá la
que tenga el mayor número de caracteres repetidos .'''
contador=0
lista=[]
lista1=[]
while(contador!=10):
    nombres=str(input("Dime nombres de cosas o personas")).upper()
    lista.append(nombres)
    contador+=1
lista_nombres=lista[0:]
contador1=0
contador2=0
contador3=1
contador4=1
contador1l=0
contador2l=0
contador3l=1
contador4l=1
acumuladori=0
acumuladorl=0
nombre_largo=""
for i in lista_nombres:
    if(len(i)>len(nombre_largo)):
        nombre_largo=i
    elif(len(i)==len(nombre_largo)):
        while(contador1!=len(i)):
            if(i[contador2]==i[contador3]):
                acumuladori+=1
                contador3+=1
                while(contador3==len(i)):
                    contador1+=1
                    contador2+=contador4
                    contador3=1 
            else:
                contador3+=1
                while(contador3==len(i)):
                    contador1+=1
                    contador2+=contador4
                    contador3=1 
        while(contador1l!=len(nombre_largo)):
            if(nombre_largo[contador2l]==nombre_largo[contador3l]):
                acumuladorl+=1
                contador3l+=1
                while(contador3l==len(nombre_largo)):
                    contador1l+=1
                    contador2l+=contador4l
                    contador3l=1   
            else:
                contador3l+=1
                while(contador3l==len(nombre_largo)):
                    contador1l+=1
                    contador2l+=contador4l
                    contador3l=1      
        if(acumuladori>acumuladorl):
            nombre_largo=i
print(nombre_largo)
#HACER CON FOR REDUCIDO       
        
