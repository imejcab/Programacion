'''Escribe una función intersect que reciba dos listas y devuelva otra lista con los
elementos que son comunes a ambas, sin repetir ninguno.'''
lista=[2,4,6,6,8]
lista1=[1,2,2,6,9,2]
lista2=[]
contador1=0
contador2=0
contador=0
while(len(lista)!=contador1):
    if(lista[contador1]==lista1[contador2]):
        lista2.append(lista[contador1])
        contador1+=1
        contador2=0
    elif(lista[contador1]!=lista1[contador2]):
        contador2+=1
        if(contador2==6):
            contador2=0
            contador1+=1
    while(len(lista2)!=contador):        
        if(lista[contador1]==lista2[contador]):
            lista2.remove(lista2[contador])
            contador=0
        elif(lista[contador1]!=lista2[contador]):
            contador+=1 
print(lista2)
'''Escribe una función unionListas que reciba dos listas y devuelva los elementos que
pertenecen a una, o bien, a la otra, pero sin repetir ninguno (unión de conjuntos).'''
lista=[1,3,3,5,2,8,8]
lista1=[2,3,5,2,8,9]
lista2=[]
contador=0
contador1=1
contador2=0
lista2.extend(lista[0:])
lista2.extend(lista1[0:])
print(lista2)
while(len(lista2)!=contador):
    if(lista2[contador]==lista2[contador1]):
        lista2.remove(lista2[contador1])
    elif(lista2[contador]!=lista2[contador1]):
        contador1+=1
    while(contador1==len(lista2)):
        contador+=1
        contador2+=1
        contador1=1+contador2
print(lista2)
        
        
        
