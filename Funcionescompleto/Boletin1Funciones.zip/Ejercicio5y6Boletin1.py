'''Realiza una función reverse que reciba una lista y devuelva una nueva lista cuyo
contenido sea igual a la original pero invertida. Así, dada la lista [‘Di’, ‘buen’, ‘día’, ‘a’,
‘papa’], deberá devolver [‘papa’, ‘a’, ‘día’, ‘buen’, ‘Di’].'''
lista=["fresa","platano","melocoton","melon","higo"]
print(lista)
fruta1=0
fruta2=0
contador1=-1
contador2=0
listainverse=[]
'''for i in lista:
    lista=i+lista
print(lista)'''
'''print(z in "Holaz que tal")'''
while(contador2!=len(lista)):
    fruta1=lista[contador2]
    fruta2=lista[contador1]
    fruta1=fruta2
    contador1-=1
    contador2+=1
    listainverse.append(fruta1)
print(listainverse)
'''Diseña una función llamada estaOrdenada que reciba una lista de elementos y
devuelva True si está ordenada o False en caso contrario.'''
mensaje=""
lista=[]
def estaordenada (lista):
    numero1=0
    while(numero>=numero1):
        numero1=numero
        mensaje="TRUE"
    if(numero<numero1):
        mensaje="FALSE"
    return mensaje
numero=int(input("¿Dime un numero?"))
lista.append(numero)
while(numero>=0): 
        numero=int(input("¿Dime un numero?"))
        lista.append(numero)
        if(numero<0):
            lista.remove(numero)
print(lista)
orden=estaordenada(lista)
print(orden)
   
        

