'''Escribir una función denominada encajan que indique si dos fichas de dominó
encajan o no. Las fichas son recibidas en dos cadenas de texto con el siguiente
formato
[3,4] [2,5]'''
#OPCION CON LISTAS
lista1=[]
lista2=[]
numero1=0
numero2=0
for i in range(2):
    numero1=int(input("¿Dime un numero?"))
    while(numero1<0 or numero1>6):
        numero1=int(input("¿Dime un numero?"))
    lista1.append(numero1)
    print(lista1)
for i in range(2):
    numero2=int(input("¿Dime un numero?"))
    while(numero2<0 or numero2>6):
        numero2=int(input("¿Dime un numero?"))
    lista2.append(numero2)   
    print(lista2)
if((lista1[0]==lista2[1])or(lista2[0]==lista1[1]) or (lista1[0]==lista2[0]) or (lista1[1]==lista2[1])):
    print(f"La ficha1 {lista1} encaja con la ficha2 {lista2}")
else:
    print(f"La ficha1 {lista1} no encaja con la ficha2 {lista2}")
#OPCION CON CADENA DE TEXTO
ficha1="[3,5]"
ficha2="[1,0]"
mensaje1=""
mensaje2=""
if ficha1[1]==("0","1","2","3","4","5","6"):
        numero1=True
else:
    numero1=False
if(numero1==True):
    if(ficha1[0]==ficha2[2]) or (ficha2[0]==ficha1[2]) or (ficha1[0]==ficha2[0]) or (ficha1[2]==ficha2[2]):
        print(f"Las piezas {ficha1} y {ficha2} encajan")
    else:
        print(f"Las piezas {ficha1} y {ficha2} no encajan")
else:
    print("Cadena de texto no valida")
        
'''Realiza un programa que añada números enteros a una lista hasta que se
introduzca un número negativo. Haciendo uso de esta lista, elabora funciones que
devuelvan:
a. una lista con todos los que sean primos.
b. el sumatorio
c. el promedio de los valores.
d. una lista con el factorial de cada uno de esos números.'''
def dividir (numero):
    if((numero%2!=0 and numero!=2) and (numero%3!=0 and numero!=3) and (numero%4!=0 and numero!=4) and (numero%5!=0 and numero!=5) and (numero%6!=0 and numero!=6) and (numero%7!=0 and numero!=7) and (numero%8!=0 and numero!=8) and (numero%9!=0 and numero!=9)):
        resultadoprimo=numero
    else:
        resultadoprimo=""
    return resultadoprimo
def sumar (numero):
    suma=0
    suma+=numero
    return suma
def promediar (numero):
    suma=0
    suma+=numero
    promedio=suma/len(lista)
    return promedio
def factorizar (numero):
    contador=0
    while(contador!=numero):
        contador+=1
        numero+=numero*numero-contador
    resultado=numero
    return resultado
lista=[]
listaprimo=[]
listafactorial=[]
numero=int(input("¿Dime un numero?"))
while(numero>=0):
    lista.append(numero)
    primo=dividir(numero)
    listaprimo.append(primo)
    factor=factorizar(numero)
    listafactorial.append(factor)
    numero=int(input("¿Dime un numero?"))
print(listaprimo)   
print(sumar(numero))     
print(promediar(numero))
print(listafactorial)
print(lista)


    
    
