'''Realiza un programa que solicite la fecha como tres datos numéricos (día, mes y
año) y muestre a continuación la fecha en formato largo.
Introduce el día de la fecha: 15
Introduce el mes de a fecha: 3
Introduce el año de a fecha: 2009
La fecha en formato largo es 15 de Marzo de 2009
Debe validar los datos y ejecutarse hasta que se introduzca un día negativo.'''
dia=int(input("¿dime un dia?"))
while(dia>0):
    while(dia>31):
        dia=int(input("¿dime un dia?"))
    mes=str(input("¿Dime un mes?"))
    while(mes!="Enero" and mes!="Febrero" and mes!="Marzo" and mes!="Abril" and mes!="Mayo" and mes!="Junio" and mes!="Julio" and mes!="Agosto" and mes!="Septiembre" and mes!="Octubre" and mes!="Noviembre" and mes!="Diciembre"):
        mes=str(input("¿Dime un mes?"))
    año=int(input("¿dime un año?"))
    while(año<0 or año>2023):
        año=int(input("¿dime un año?"))
    while((mes=="Abril" and dia==31) or (mes=="Junio" and dia==31) or (mes=="Mayo" and (dia>28 and dia<=31)) or (mes=="Septiembre" and dia==31) or (mes=="Noviembre" and dia==31)):
        dia=int(input("¿dime un dia?"))
        while(dia>31):
            dia=int(input("¿dime un dia?"))
        mes=str(input("¿Dime un mes?"))
        while(mes!="Enero" and mes!="Febrero" and mes!="Marzo" and mes!="Abril" and mes!="Mayo" and mes!="Junio" and mes!="Julio" and mes!="Agosto" and mes!="Septiembre" and mes!="Octubre" and mes!="Noviembre" and mes!="Diciembre"):
            mes=str(input("¿Dime un mes?"))
        año=int(input("¿dime un año?"))
        while(año<0 or año>2023):
            año=int(input("¿dime un año?"))
    print(f"La fecha en formato largo es {dia} de {mes} de {año}")
    dia=int(input("¿dime un dia?"))
#ALTERNATIVA CLASE
def es_bisiesto(year):
    return (year%4==0 and (year%100!=0 or year%400==0))
def es_fecha_valida(d, m, y):
    dias_maximo_por_mes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return (1<= d <= dias_maximo_por_mes[m-1]
            or (es_bisiesto(y) and m==2 and 1<=d<=29))
def transformar_fecha(day, month, year):
    nombre_meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
    if es_fecha_valida(day, month, year):
        mes_largo = nombre_meses[month-1]
        resultado = f"{day} de {mes_largo} de {year}"
    else:
        resultado = "La fecha introducida es incorrecta."
    return resultado
dia= int(input("Introduzca un día: "))
mes= int(input("Introduzca un mes válido: "))
año= int(input("Introduzca un mes válido: "))
while dia >= 0:
    print(transformar_fecha(dia, mes, año))
    dia= int(input("Introduzca un día: "))
    mes= int(input("Introduzca un mes válido: "))
    año= int(input("Introduzca un mes válido: "))
#EJERCICIO 4
'''Crea un programa que lea por teclado números de forma sucesiva y los guarde en
una lista; el proceso de lectura y guardado finalizará cuando metamos un número
negativo. En ese momento se mostrará el elemento mayor y los números pares.'''
lista=[]
mensaje=""
numero1=0
def elementomayor (numero,numero1):
    if(numero>numero1):
        numero1=numero
        resultadomayor=numero1
    else:
        resultadomayor=numero1
    return resultadomayor
def contarpares (numero):
    if(numero%2==0):
        mensaje=f"El numero {numero} es par"
    else:
        mensaje=""
    return mensaje
numero=0
while(numero>=0):
    numero=int(input("¿Dime un numero?"))
    if(numero>=0):
        lista.append(numero)
        if(numero>numero1):
            numero1=numero
            resultadomayor=numero1
        else:
            resultadomayor=numero1
        print(f"El numero mayor es {resultadomayor}")
        par=contarpares(numero)
        print(par)
print(lista)
def elementomayorr (lista):
    contador=0
    numero1=0
    while(len(lista)!=contador):
        if(numero>numero1):
            numero1=numero
            contador+=1
            resultadomayor=numero1
        else:
            contador+=1
            resultadomayor=numero1
    return resultadomayor
def contarparess (numero):
    if(numero%2==0):
        mensaje=f"El numero {numero} es par"
    else:
        mensaje=""
    return mensaje
lista=[]
numero=int(input("Dime numeros y uno negativo para parar"))
lista.append(numero)
while(numero>=0):
    numero=int(input("Dime numeros y uno negativo para parar"))
    lista.append(numero)
mayor=elementomayorr(lista)
print(mayor)

        
        
        
        
        

            