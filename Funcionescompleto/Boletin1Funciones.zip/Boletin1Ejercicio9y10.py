'''Desarrolla un programa que a partir de una lista de números y un entero k, realice la
llamada a tres funciones: a) para devolver una lista de números con los menores de
k, b) otra con los mayores y c) otra con aquellos que son múltiplos de k.'''
#PROCESAMIENTO
def menork (numero,k):
    return numero<k
def mayork (numero,k):    
    return numero>k
def multiplok (numero,k):
    return numero%k==0
#PEDIR DATOS
def pidodatos ():
    contador=0
    contador1=10
    while(contador!=contador1):
        contador+=1
        numero=int(input("¿Dime un numero?"))
    k=int(input("¿Dime un numero"))
    return numero,k
#SALIDA INFORMACION
def mostrarresultado (numero):
    if(numero<k):
        print(menork(numero,k))
    elif(numero>k):
        print(mayork(numero,k))
    if(numero%k==0):
        print(multiplok(numero,k))
    return numero
datos=pidodatos()
k=datos[1]
numero=datos[0]
print(mostrarresultado(numero))
#SIN LISTAS NI FUNCIONES
listamenor=[]
listamayor=[]
listamultiplo=[]
k=int(input("¿Dime un numero?"))
contador=0
contador1=10
while(contador!=contador1):
    numero=int(input("¿Dime un numero?"))
    contador+=1
    if(numero<k):
        listamenor.append(numero)
    elif(numero>k):
        listamayor.append(numero)
    if(numero%k==0):
        listamultiplo.append(numero)
print(listamenor)
print(listamayor)
print(listamultiplo)
#REINVENTADO
#PROCESAMIENTO
listamenor1=[]
listamayor1=[]
listamultiplo1=[]
contador=0
contador1=10
while(contador!=contador1):
    contador+=1
    numero=int(input("¿Dime un numero?"))
k=int(input("¿Dime un numero"))
if(numero<k):
    print(menork(numero,k))
    listamenor1.append(numero)
elif(numero>k):
    print(mayork(numero,k))
    listamayor1.append(numero)
if(numero%k==0):
    print(multiplok(numero,k))
    listamultiplo1.append(numero) 
print(listamenor1)   
print(listamayor1)
print(listamultiplo1)
'''Diseña una función conversor que convierta un número de binario a decimal o de
decimal a binario. Esta función recibirá un número en formato de cadena de texto
cuya última posición indica el sistema numérico utilizado (D-decimal, B-binario).
Debe validar la información, así, por ejemplo, el número ‘1020101B’ no sería válido
puesto que los valores en binario son 0 y'''
numero=str(input("Dime numero y una letra B o D al final"))
while(numero[-1]!="D" and numero[-1]!="B"):
    numero=str(input("Dime numero y una letra B o D al final"))
if(numero[-1]=="D"):
    numero=int(numero[0:-1])
    resto=0
    lista=[]
    mensaje=""
    contador1=0
    contador2=-1
    while(numero>=1):
        if(numero==1):
            resto=1
            numero=0
            mensaje+=resto
            lista.append(resto)
        elif(numero%2==0):
            resto=0
            numero=int(numero/2)
            mensaje+=resto
            lista.append(resto)
        elif(numero%2==1):
            resto=1
            numero=int(numero/2)
            mensaje+=resto
            lista.append(resto)
            while(contador1!=len(lista)):
                lista[contador2]=lista[contador1]
                contador1+=1
                contador2-=1
        resto=lista[0:]
        print(resto)
        print(mensaje)
elif(numero[-1]=="B"):
    numero="10001100B"
    numero1=numero[0:-1]
    contador=0
    resultado=0
    while(contador!=len(numero1)):
        if(numero1[contador]==0):
            resultado+=0
            contador+=1
        elif(numero1[contador]==1):
            resultado+=2*contador
            contador+=1
    print(resultado)
        
    
        
        
       
    
        
        
    