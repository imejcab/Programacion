'''Diseñe un método llamado isPrime que reciba un número entero positivo mayor
que 0 como parámetro. El método debe devolver True si el número es primo o False si
no primo Si el parámetro no es válido, el método debe devolver Ninguno.'''
def isprime (numero):
    contador=0
    i=2
    contador1=0
    while(contador!=1):
        if(numero<0):
            resultado="Ninguno"
        elif(numero>=0):
            if(numero%i==0):
                contador=1
                contador1=1
                i+=1
            else:
                i+=1
                if(i==numero and contador==0):
                    contador=1
                    contador1=0
    if(contador1==1):
        resultado=False
    elif(contador1==0):
        resultado=True
    return resultado
numero=int(input("Dime un numero"))
if(numero>=0):
    primo=isprime(numero)
    print(primo)
else:
    resultado="Ninguno"
    print(resultado)
'''8. Diseñe un método llamado solveSecondOrderEquation que reciba tres enteros
números positivos correspondientes a los coeficientes de una ecuación de segundo orden
((ax
2+bx+c=0)
) y calcula sus posibles soluciones. Si los parámetros no son válidos, el
El método debe devolver Ninguno.'''
def solvesecondorderequation (a,b,c):
    contador=-b/2*a
    x1=(((b**2)-4*a*c)**(0.5)/2*a)
    resultado1=x1+int(contador)
    resultado2=x1-int(contador)
    return resultado1,resultado2
a=int(input("Dime un numero"))
b=int(input("Dime un numero"))
c=int(input("Dime un numero"))
resultado=solvesecondorderequation(a,b,c)
if(a>=0 and b>=0 and c>=0):
    print(type(resultado[0]))
    print(resultado[0])
    print(type(resultado[1]))
    print(resultado[1])
else:
    resultado="Ninguno"
    print(resultado)


            