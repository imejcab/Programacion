'''1. Diseñe un método llamado computeFactorial que reciba un entero positivo y
devuelve el factorial para ese número. Si el número es negativo, el método debe
devuelve Ninguno.'''
def computefactorial (numero):
    contador=1
    contador1=1
    factorial=0
    acumulador=numero
    while(contador!=numero):
        if(numero>=0):
            acumulador=acumulador*(numero-contador1)
            factorial=acumulador
            contador+=1
            contador1+=1
        else:
            print("Valor 0 fin del ejercicio")
            contador=numero
    return factorial
numero=int(input("¿Dime un numero positivo?"))
factorial=computefactorial(numero)
print(factorial)
while(numero>=0):
    numero=int(input("¿Dime un numero positivo?"))
    factorial=computefactorial(numero)
    print(factorial)
'''2. Diseñe un método llamado esAñoBisiesto que reciba un número y devuelva Falso para
años comunes y True para años bisiestos. Usted puede saber que un año se considera
ser un año bisiesto si es divisible por 4, a menos que también sea divisible por 100. Un año no es un
año bisiesto si es divisible por 100 a menos que también sea divisible por 400.'''
def esañobisiesto (año):
    if((año%4==0 and (año%100!=0 or año%400==0))):
        bisiesto=True
    else:
        bisiesto=False
    return bisiesto
año=0
while(año>=0):
    año=int(input("¿Dime un año?"))
    if(año<0):
        print("Numero no valido")
    añobisiesto=esañobisiesto(año)
    print(añobisiesto)
