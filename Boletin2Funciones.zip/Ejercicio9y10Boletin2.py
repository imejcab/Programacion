'''9. Diseñe un método llamado getPrimeDivisors que reciba un número positivo como
parámetro y devuelve una lista que contiene sus divisores primos. Si el parámetro no es válido
el método debe devolver Ninguno.'''
def getprimedivisors (numero):
    lista=[]
    contador=1
    contador1=0
    contador2=2
    while(contador!=numero+1):
        if(numero%contador==0):
            lista.append(contador)
            print(lista)
            contador+=1
        else:
            contador+=1
    while(contador1!=len(lista)):
        if(lista[contador1]%contador2==0 and contador2!=lista[contador1]):
            lista.remove(lista[contador1])
        else:
            contador2+=1
            if(contador2>(lista[contador1])):
                contador2=2
                contador1+=1
    resultado=lista[0:]
    return resultado
numero=int(input("Dime un numero positivo"))
if(numero>0):
    primo_divisor=getprimedivisors(numero)
    print(primo_divisor)
else:
    resultado="Ninguno"
    print(resultado)
'''10. Diseñe un método llamado isFriendNumber que reciba dos números positivos y
devuelve True si los números son amigos, False en caso contrario. dos numeros son
considerados amigos si la suma de sus divisores, excepto el número dado, es igual
al segundo y viceversa.'''
def isfriendnumber (numero1,numero2):
    contador1=1
    contador2=1
    acumulador1=0
    acumulador2=0
    while(contador1!=numero1):
        if(numero1%contador1==0):
            acumulador1+=contador1
            contador1+=1
        else:
            contador1+=1
    while(contador2!=numero2):
        if(numero2%contador2==0):
            acumulador2+=contador2
            contador2+=1
        else:
            contador2+=1
    if((acumulador1==numero2) and (acumulador2==numero1)):
        resultado=True
    else:
        resultado=False
    return resultado
numero1=int(input("Dime un numero positivo"))
while(numero1<0):
    numero1=int(input("Dime un numero positivoo"))
numero2=int(input("Dime un numero positivo"))
while(numero2<0):
    numero2=int(input("Dime un numero positivoo"))
amigos=isfriendnumber(numero1,numero2)
print(amigos)
            

                
            
    
            
        
            
