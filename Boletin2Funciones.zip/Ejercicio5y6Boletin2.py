'''5. Diseñe un método llamado powerIt que reciba dos enteros y eleve el primer
número con el segundo. Puede usar el producto o la recursividad y verificar los valores. Si
no se proporciona ningún exponente, el primer número se eleva a 0.'''
def powerit (numero1,numero2):
    resultado=numero1**numero2
    return resultado
numero1=4
numero2=9
if(numero2==""):
    numero2=0
potencia=powerit(numero1,numero2)
print(potencia)
assert(powerit(4,2)==16)
'''6. Diseñe un método llamado getNumberOfDigits que reciba un número (puede ser
real, entero, positivo o negativo) y debe devolver el número de dígitos que contiene. Si
el parámetro no es válido, el método debería devolver Ninguno. Extender esta función a
otros sistemas numéricos (hexadecimal, decimal, binario, octal).'''
lista=[1,2,3,4,5,6,7,8,9]
def getnumberofdigits (numero):
    contador=0
    while(contador!=len(numero)):
        contador+=1
        resultado=contador-contadorresta
    return resultado
numero=str(input("Dime un numero"))
contador1=0
contadorresta=0
while(len(numero)!=contador1):
    if(numero[contador1] not in lista):
        contadorresta+=1
        contador1+=1
    elif(numero[contador1] in lista):    
        contador1+=1
    if(numero[0] in lista or numero[-1] in lista):
        digitos=getnumberofdigits(numero)
        print(digitos)
    if(contadorresta>1):
        resultado="Ninguno"
    else:
        resultado="Ninguno"
#OPCION EXTENSION EJERCICIO
def getnumberofdigitss (numeros):
    contador=0
    if(opcion=="hexadecimal"):
        while(numeros>=16):
            numeros=numeros/16
            contador+=1
            resultado=contador
    elif(opcion=="decimal"):
        while(numeros>=10):
            numeros=numeros/10
            contador+=1
            resultado=contador
    elif(opcion=="binario"):
        while(numeros>=2):
            numeros=numeros/2
            contador+=1
            resultado=contador
    else:
        while(numeros>=8):
            numeros=numeros/8
            contador+=1
            resultado=contador
    return resultado
opcion=str(input("Dime una opcion (hexadecimal,decimal,binario,octal)"))
if(opcion!="hexadecimal" and opcion!="decimal" and opcion!="binario" and opcion!="octal"):
    resultado="Ninguno"
    print(resultado)
numeros=int(input("Dime un numero"))
digit=getnumberofdigitss(numeros)
print(digit)
           
            


