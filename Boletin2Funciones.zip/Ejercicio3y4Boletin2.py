'''3. Diseñe un método llamado computeDaysInMonth que devuelva el número de días para
el mes y el año que se reciben como argumentos. Puede utilizar el método
año bisiesto anterior. Si los valores no son válidos, el método debería devolver -1.'''
def computedaysinmonth (mes,año):
    dias_mes=[28,29,30,31]
    dias=0
    if(mes=="febrero" and (año%4==0 and (año%100!=100 or año%400==0))):
        dias=dias_mes[1]
    elif(mes=="febrero" and not(año%4==0 and (año%100!=100 or año%400==0))):
        dias=dias_mes[0]
    elif(mes=="abril" or mes=="junio" or mes=="septiembre" or mes=="noviembre"):
        dias=dias_mes[2]
    else:
        dias=dias_mes[3]
    return dias
año=int(input("¿Dime un año?"))
if(año<0 and año>=2023):
    dias=-1 
    print(dias)
mes=str(input("¿Dime un mes?"))
if(mes!="enero" and mes!="febrero" and mes!="marzo" and mes!="abril" and mes!="mayo" and mes!="junio" and mes!="julio" and mes!="agosto" and mes!="septiembre" and mes!="octubre" and mes!="noviembre" and mes!="diciembre"):
    dias=-1
    print(dias)
else:  
    computar=computedaysinmonth(mes,año)
    print(computar)
'''4. Diseñe un método llamado getDayOfWeek que reciba una lista que contenga tres números enteros
(día, mes y año) y devuelve el día de la semana para esa fecha (lunes,
Martes Miércoles Jueves Viernes Sábado Domingo).
Puede usar el siguiente algoritmo para obtener un número entre 0 (domingo) y 6
(sábado) correspondiente al día de la semana para una fecha determinada:
a = (14 - mes) / 12
y = año – a
m = mes + 12 * a – 2
d = (día + y + y/4 - y/100 + y/400 + (31*m)/12) módulo 7'''
def getdayofweek (lista):
    a=(14-mes)/12
    y=año-a
    m=mes+12*a-2
    d=(dia+y+y/4-y/100+y/400+(31*m)/12)%7
    d=int(d)
    if(d==0):
        resultado=dias_semana[-1]
    else:
        contador=0
        while(d!=contador):
            contador+=1
        if(d==contador):
            resultado=dias_semana[contador]
    return resultado
dias_semana=["lunes","martes","miercoles","jueves","viernes","sabado","domingo"]
lista=[]
año=int(input("Dime un numero para año"))
while(año<0 or año>2023):
    año=int(input("Dime un dia para año"))   
mes=int(input("Dime un numero para mes"))
while(mes<=0 or mes>12):
    mes=int(input("Dime un numero para mes"))
dia=int(input("Dime un numero para dia"))
while(dia<=0 and ((dia>31 and (mes==1 or mes==3 or mes==5 or mes==7 or mes==8 or mes==10 or mes==12) or (dia>28 and mes==2) or (dia>30 and (mes==4 or mes==6 or mes==9 or mes==11))))):
    dia=int(input("Dime un numero para dia"))
lista.append(dia)  
lista.append(mes)
lista.append(año)
dia_semanal=getdayofweek (lista)
print(dia_semanal)

       
    
          
    
        

    

