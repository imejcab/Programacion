package MockExam;

import java.time.LocalDateTime;
import java.util.Objects;

public abstract class Publicacion{
	/*Atributos*/
	protected String texto;
	private LocalDateTime fechaCreacion;
	protected int valoracion;
	private int codigo;
	private static int codigoSiguiente=0;
	
	/*Constructor*/
	public Publicacion(String texto, LocalDateTime fechaCreacion, int valoracion, int codigo) throws PublicacionException {
		super();
		setTexto(texto);
		this.fechaCreacion = LocalDateTime.now();
		this.valoracion = valoracion;
		this.codigo = codigoSiguiente++;
	}
	public String getTexto() {
		return texto;
	}
	abstract protected void setTexto(String texto) throws PublicacionException;
	public boolean Valorar(String valoracion) {
		boolean esPosibleValorar=false;
		try {
			Valoraciones valoraciones=Valoraciones.valueOf(valoracion.toUpperCase());
			this.valoracion+=valoraciones.getValoracion();
			esPosibleValorar=true;
		}catch (Exception e) {
			
		}
		return esPosibleValorar;
	}
	public LocalDateTime getFechaCreacion() {
		return fechaCreacion;
	}
	public int getValoracion() {
		return valoracion;
	}
	public int getCodigo() {
		return codigo;
	}
	@Override
	public int hashCode() {
		return Objects.hash(codigo, fechaCreacion, texto, valoracion);
	}
	@Override
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Publicacion other = (Publicacion) obj;
		if(codigo == other.codigo && Objects.equals(fechaCreacion, other.fechaCreacion)
				&& Objects.equals(texto, other.texto) && valoracion == other.valoracion) {
			resultado=true;
		}
		return resultado;
	}
	@Override
	public String toString() {
		return String.format("Publicacion [texto=" + texto + ", fechaCreacion=" + fechaCreacion + ", valoracion=" + valoracion
				+ ", codigo=" + codigo + "]");
	}
	public int compareTo(Publicacion otro) {
		int resultado=0;
		if(this.valoracion==otro.valoracion) {
			resultado=this.fechaCreacion.compareTo(otro.fechaCreacion);
		}else {
			resultado=this.valoracion-otro.valoracion;
		}
		return resultado;
	}
}
