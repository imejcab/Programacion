package MockExam;

import java.util.Objects;

public class Usuario {
	/*Atributos*/
	private String login;
	private String pass;
	/*Constructor*/
	public Usuario(String login, String pass) {
		super();
		this.login = login;
		this.pass = pass;
	}
	/*Metodos*/
	public String getLogin() {
		return login;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	@Override
	public int hashCode() {
		return Objects.hash(login, pass);
	}
	@Override
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado= true;
		}else if (obj == null) {
			resultado= false;
		}else if (getClass() != obj.getClass()) {
			resultado= false;
		}
		Usuario other = (Usuario) obj;
		if(Objects.equals(login, other.login) && Objects.equals(pass, other.pass)) {
			resultado=true;
		}
		return resultado;
	}
}
