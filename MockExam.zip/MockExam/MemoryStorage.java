package MockExam;

public class MemoryStorage {
	public static final int MAXUSUARIOS=15;
	public static final int MAXPUBLICACIONES=50;
	private Usuario [] usuarios;
	private Publicacion [] publicaciones;
	private int numUsuariosActuales;
	private int numPublicacionesActuales;
	public MemoryStorage(Usuario[] usuarios, Publicacion[] publicaciones) {
		super();
		this.usuarios = new Usuario [MAXUSUARIOS];
		this.publicaciones = new Publicacion [MAXPUBLICACIONES];
		this.numUsuariosActuales = numUsuariosActuales;
		this.numPublicacionesActuales = numPublicacionesActuales;
	}
}
