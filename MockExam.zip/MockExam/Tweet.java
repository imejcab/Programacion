package MockExam;

import java.time.LocalDateTime;

public class Tweet extends Publicacion {

	public Tweet(String texto, LocalDateTime fechaCreacion, int valoracion, int codigo) throws PublicacionException {
		super(texto, fechaCreacion, valoracion, codigo);
	}
	@Override
	protected void setTexto(String texto) {
		this.valoracion=this.valoracion*2;
	}
	@Override
	public String toString() {
		return String.format("Tweet [texto=" + texto + ", valoracion=" + valoracion + "]");
	}
}
