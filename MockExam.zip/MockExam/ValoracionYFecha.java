package MockExam;
import java.time.LocalDateTime;
import java.util.Comparator;

public class ValoracionYFecha implements Comparator<Publicacion> {
	public int compare(Publicacion o1, Publicacion o2) {
		int resultado=0;
		if(o1!=null || o2!=null) {
			if(o1.getValoracion()==o2.getValoracion()) {
				resultado=o1.getFechaCreacion().compareTo(o2.getFechaCreacion());
			}else {
				resultado=o1.getValoracion()-o2.getValoracion();
			}
		}else if(o1==null) {
			resultado=1;
		}else if(o2==null) {
			resultado=-1;
		}
		return resultado;
	}
	
}
