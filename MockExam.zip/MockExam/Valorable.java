package MockExam;
public interface Valorable{
	void Valorar(String valoracion);
}
