package MockExam;
import java.time.LocalDateTime;
import java.util.Scanner;
public class PrincipalJava {
	Scanner sc=new Scanner (System.in);
		public static void main(String [] args)  {
			try {
				Publicacion p1=new Tweet ("Hola Mundo", LocalDateTime.now(), 5, 3 );
				System.out.println(p1);
			}catch (PublicacionException e) {
				e.printStackTrace();
			}
			try {
				Publicacion p2=new Post ("Hola Mundo",LocalDateTime.now(), 5, 3 , 1,"yvt");
				System.out.println(p2);
			}catch (PublicacionException e) {
				e.printStackTrace();
			}
			Usuario u1= new Usuario("Ivan", "fhwbfwh");
			System.out.println(u1.hashCode());
		}
	}
