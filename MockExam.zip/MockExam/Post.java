package MockExam;

import java.time.LocalDateTime;

public class Post extends Publicacion {
	private int numeroLecturas;
	private String tema;
	public Post(String texto, LocalDateTime fechaCreacion, int valoracion, int codigo, int numeroLecturas,
			String tema) throws PublicacionException {
		super(texto, fechaCreacion, valoracion, codigo);
		this.numeroLecturas = numeroLecturas;
		this.tema = tema;
	}
	@Override
	protected void setTexto(String texto) throws PublicacionException {
		if(texto==null || texto.length()>50) {
			throw new PublicacionException("El post no puede estar vacio");
		}
		this.texto=texto;
	}
	public int getNumeroLecturas() {
		return numeroLecturas;
	}
	@Override
	public String toString() {
		return String.format("Post [numeroLecturas=" + numeroLecturas + ", tema=" + tema + "]");
	}
}
