package MockExam;

import java.time.LocalDateTime;

public class Recomendacion extends Publicacion {
	public static final int MAXIMOCARACTER=200;
	public static final int MINIMOCARACTER=100;
	private int numeroEstrellas;
	public Recomendacion(String texto, LocalDateTime fechaCreacion, int valoracion, int codigo, int numeroEstrellas) throws PublicacionException {
		super(texto, fechaCreacion, valoracion, codigo);
		if(numeroEstrellas <1 || numeroEstrellas>5) {
			throw new PublicacionException("El numero de estrellas no es valido");
		}
		this.numeroEstrellas = numeroEstrellas;
	}
	@Override
	protected void setTexto(String texto) throws PublicacionException {
		if(texto.length()>MAXIMOCARACTER || texto.length()<MINIMOCARACTER) {
			throw new PublicacionException("Numero de caracteres no permitido");
		}
	}
	public int getNumeroEstrellas() {
		return numeroEstrellas;
	}
	@Override
	public String toString() {
		return String.format("Recomendacion [numeroEstrellas=" + numeroEstrellas + "]");
	}
}
