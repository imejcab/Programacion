package com.edu;
import java.util.Scanner;
public class Ejercicio15 {
	public static void main(String[] args) {
		/*15. Crea un programa que permita sumar N números. El usuario decide cuándo termina
		de introducir números al indicar la palabra ‘fin’.*/
		Scanner sc=new Scanner(System.in);
		int suma=0;
		String valor="";
		while(!valor.equals("fin")) {
			System.out.println("Dime un numero");
			valor=sc.nextLine();
			if(!valor.equals("fin")) {
				suma+=Integer.valueOf(valor);
			}
			}
		System.out.println("la suma es: " + suma);
		}
	}
