package com.edu;
import java.util.Scanner;
public class Ejercicio7 {
	public static final int LIMITE_SUPERIOR=100;
	public static final int LIMITE_INFERIOR=1;
	public static void main(String [] args) {
		/*7. Codifica las siguientes secuencias numéricas haciendo uso de estructuras: i) for, ii)
while, iii) do-while en cada una de ellas:
a. Crea un método que muestre los números del 1 al 100
b. Repite el ejercicio anterior, pero en formato descendente, es decir, del 100 al 1.
c. Crea un programa que calcule y escriba los números múltiplos de 5 de 0 a 100.
d. Escribe los números del 320 al 160, contando de 20 en 20 hacia atrás.*/
		int numero;
		Scanner sc=new Scanner(System.in);
		for(numero=1;numero<=100;numero++) {
			System.out.println(numero);
		}
		for(numero=100;numero>=1;numero--) {
			System.out.println(numero);
		}
		for(numero=0;numero<=100;numero++) {
			if(numero%5==0) {
				System.out.println(numero);
			}
		}
		for(numero=320;numero>=160;numero-=20) {
			System.out.println(numero);
		}
		numero=1;
		while(numero<=100) {
			System.out.println(numero);
			numero++;
		}
		numero=100;
		while(numero>=1) {
			System.out.println(numero);
			numero--;
		}
		numero=0;
		while(numero<=100) {
			if(numero%5==0) {
				System.out.println(numero);
				numero++;
			}else {
				numero++;
			}
		}
		numero=320;
		while(numero>=120) {
			System.out.println(numero);
			numero-=20;
		}
		numero=1;
		do {
			System.out.println(numero);
			numero++;
		}while(numero<=100);
		numero=100;
		do {
			System.out.println(numero);
			numero--;
		}while(numero>=1);
		numero=0;
		do {
			if(numero%5==0) {
				System.out.println(numero);
				numero++;
			}else{
				numero++;
			}
		}while(numero<=100);
		numero=320;
		do {
			System.out.println(numero);
			numero-=20;
		}while(numero>=120);
	}
}

