package com.edu;
import java.util.Scanner;
public class Ejercicio11 {
	public static void main(String [] args) {
		/*11 Realiza un programa que pida números y muestre su cuadrado, repitiendo el
proceso hasta que se introduzca un número negativo.*/
		Scanner sc=new Scanner(System.in);
		int numero;
		do {
			System.out.println("Dime un numero");
			numero=Integer.valueOf(sc.nextLine());
			if(numero>=0) {
				System.out.println("Su cuadrado es:  " + numero*numero);
			}
		}while(numero>=0);
	}
}
