package com.edu;
import java.util.Scanner;
public class Ejercicio4 {
	public static void main (String [] args) {
		/*4. Calcular las calificaciones de un alumno con un método que reciba la nota de la
parte práctica, la nota de los problemas y la parte teórica. La nota final se calcula
según el siguiente criterio: la parte práctica vale el 10%; la parte de problemas vale
el 50% y la parte teórica el 40%. Las notas deben estar entre 0 y 10, si no lo están,
deberá devolver un mensaje de error.
Realiza el método que calcule la media de tres notas y te devuelva la nota del
boletín (insuficiente, suficiente, bien, notable o sobresaliente).*/
		Scanner sc=new Scanner(System.in);
		float nota_practica,nota_problemas,nota_teoria;
		System.out.println("Dime la nota practica:");
		nota_practica=Integer.valueOf(sc.nextLine());
		System.out.println("Dime la nota de problemas:");
		nota_problemas=Integer.valueOf(sc.nextLine());
		System.out.println("Dime la nota teorica:");
		nota_teoria=Integer.valueOf(sc.nextLine());
		double media=(nota_practica*0.1)+(nota_problemas*0.5)+(nota_teoria*0.4);
		if(media<4) {
			System.out.println("Es Insuficiente la nota:" + media);
		}else if(media>=5 && media<6) {
			System.out.println("Es suficiente la nota:" + media);
		}else if(media>=6 && media<7) {
			System.out.println("Es bien la nota:" + media);
		}else if(media>=7 && media<9) {
			System.out.println("Es notable la nota:" + media);
		}else if(media>=9) {
			System.out.println("Es sobresaliente la nota:" + media);
		}
	}
}
