package com.edu;
import java.util.Scanner;
//import java.util.ArrayList;
//import java.util.List;
public class Ejercicio17 {
	public static final int NUMERO_SEQUENCIAS=15;
	public static void main(String [] args) {
		/*17. Escribe un programa que muestre los N primeros términos de la serie de Fibonacci.
El primer término de la serie de Fibonacci es 1, el segundo es 1 y el resto se calcula
sumando los dos anteriores, por lo que tendríamos que los términos son 1, 1, 2, 3, 5,
8, 13, 21, 34, 55, 89, 144.*/
		int numero_anterior=0, numero=1, contadorx;
		StringBuilder sb=new StringBuilder();
		for(int contador=0;contador<NUMERO_SEQUENCIAS;contador++) {
			contadorx=numero_anterior+numero;
			sb.append(numero).append(" ");
			numero_anterior=numero;
			numero=contadorx;
		}
		System.out.println(sb.toString());
	}
}
