package com.edu;
import java.util.Scanner;
public class Ejercicio5 {
	public static void main(String [] args) {
		/*5. Realiza un método que reciba una hora por parámetro y que muestre luego buenos
días, buenas tardes o buenas noches según corresponda. Se utilizarán los tramos
de 6 a 12, de 13 a 20 y de 21 a 5, respectivamente, sólo teniendo en cuenta el valor
de las horas.*/
		Scanner sc=new Scanner(System.in);
		int hora;
		do {
			System.out.println("Dime una hora:");
			hora=Integer.valueOf(sc.nextLine());
		}while(hora<1 && hora>24);
		if(hora>5 && hora<13) {
			System.out.println("Buenos dias");
		}else if(hora>12 && hora<21) {
			System.out.println("Buenas tardes");
		}else if((hora>20 && hora<=24) || (hora>0 && hora<6)) {
			System.out.println("Buenas noches");
		}
	}
}
