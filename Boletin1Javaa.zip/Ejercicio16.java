package com.edu;
import java.util.Scanner;
public class Ejercicio16 {
	public static void main(String [] args) {
		/*16. Pedir 10 valores numéricos que representan el salario mensual de 10 empleados.
		Mostrar su suma y cuantos hay mayores de 1000€.*/
		Scanner sc=new Scanner(System.in);
		//sc.useLocale(Locale.US);
		double suma=0;
		int mayores=0;
		double salario;
		for(int contador=0; contador<10;contador++) {
			do {
				System.out.println("Dime un salario");
				salario=Double.valueOf(sc.nextLine());
			}while(salario<0 || salario>50000);
			suma+=salario;
			if(salario>1000) {
				mayores++;
			}
		}
		System.out.println("la suma de salarios es " + suma + " y la suma de salarios mayores a 1000 euros es  " + mayores);
	}
}
