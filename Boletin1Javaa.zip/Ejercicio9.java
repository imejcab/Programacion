package com.edu;
import java.util.Scanner;
public class Ejercicio9 {
	public static void main(String [] args) {
		/*9. Método que pida 5 números e imprima si alguno es múltiplo de 3.*/
		Scanner sc=new Scanner(System.in);
		int contador=0;
		int numero;
		while(contador<5) {
			contador++;
			System.out.println("Dime un numero");
			numero=Integer.valueOf(sc.nextLine());
			if(numero%3==0) {
				System.out.println("Es multiplo de 3 el numero:"+numero);
			}
		}
		
	}
}
