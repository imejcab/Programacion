package com.edu;
import java.util.Scanner;
public class Ejercicio6 {
	public static void main(String[] args) {
		/*6. Programar un sistema de calefacción-refrigeración que compruebe en función del
día y el mes, la estación en la que estamos y dependiendo de la estación programe
la temperatura: Invierno→19º, Primavera→20º, Verano→24º, Otoño→19º.
El método deberá recibir como parámetro el mes y el día actual y devolver los
grados a los que deberemos programar el sistema.*/
		Scanner sc=new Scanner(System.in);
		int dia;
		String mes;
		do {
			System.out.println("Dime un mes del año");
			mes=sc.nextLine();
		}while(!(mes.equals("enero")) && !(mes.equals("febrero")) && !(mes.equals("marzo")) && !(mes.equals("abril")) && !(mes.equals("mayo")) && !(mes.equals("junio")) && !(mes.equals("julio")) && !(mes.equals("agosto")) && !(mes.equals("septiembre")) && !(mes.equals("octubre")) && !(mes.equals("noviembre")) && !(mes.equals("diciembre")));
		do {
			System.out.println("Dime en que dia estamos");
			dia=Integer.valueOf(sc.nextLine());
		}while((mes.equals("enero") && (dia<0 || dia>31)) || (mes.equals("febrero") && (dia<0 || dia>28)) || (mes.equals("marzo") && (dia<0 || dia>31) || (mes.equals("abril") && (dia<0 || dia>30)) || (mes.equals("mayo") && (dia<0 || dia>31)) || (mes.equals("junio") && (dia<0 || dia>30)) || (mes.equals("julio") && (dia<0 || dia>31)) || (mes.equals("agosto")&& (dia<0 || dia>31)) || (mes.equals("septiembre")&& (dia<0 || dia>30)) || (mes.equals("octubre")&& (dia<0 || dia>31)) || (mes.equals("noviembre")&& (dia<0 || dia>30)) || (mes.equals("diciembre")&& (dia<0 || dia>31))));
		if((mes.equals("marzo") && dia>19) || mes.equals("abril") || mes.equals("mayo") || ((mes.equals("junio") && (dia>20)))){
			System.out.println("Primavera");
		}else if((mes.equals("junio") && dia>20) || mes.equals("julio") || mes.equals("agosto") || ((mes.equals("septiembre") && (dia>22)))){
			System.out.println("Verano");
		}else if((mes.equals("septiembre") && dia>22) || mes.equals("octubre") || mes.equals("noviembre") || ((mes.equals("diciembre") && (dia>20)))){
			System.out.println("Otoño");
		}else if((mes.equals("diciembre") && dia>20) || mes.equals("enero") || mes.equals("febrero") || ((mes.equals("marzo") && (dia>19)))) {
			System.out.println("Invierno");
		}
	}
}
