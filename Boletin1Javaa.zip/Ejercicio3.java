package com.edu;
import java.util.Scanner;
public class Ejercicio3 {
	public static void main(String [] args) {
		/*3. Escribir un método que reciba un carácter y devuelva el tipo de carácter que es.
		Debe devolver una de los siguientes mensajes según corresponda:
			◦ Letra mayúscula
			◦ Letra minúscula
			◦ Dígito entre 0 y 9
			◦ Signo de puntuación
			◦ Espacio en blanco
			◦ Paréntesis () o llaves {}
			◦ Otro carácter*/
		Scanner sc=new Scanner (System.in);
		char caracter;
		String mensaje="";
		System.out.println("Dime un caracter");
		caracter=sc.next().charAt(0);
		if(Character.isLowerCase(caracter)) {
			System.out.println("Letra minuscula");
		}else if(Character.isUpperCase(caracter)){
			System.out.println("Letra mayuscula");
		}else if(Character.isDigit(caracter)) {
			System.out.println("Digito entre 0 y 9");
		}else if(caracter==' '){
			System.out.println("Espacios en blanco");
		}else if(caracter=='(' || caracter==')'){
			System.out.println("Es una llave");
		}else if(caracter=='{' || caracter=='}') {
			System.out.println("Es una llave");
		}else if(caracter=='.' || caracter==',' || caracter==':' || caracter==';' || caracter=='/') {
			System.out.println("Es un tipo de puntuacion");
		}
		System.out.println(definir_caracter(caracter));
	}
	//FUNCION
	public static String definir_caracter(char caracter) {
		Scanner sc=new Scanner (System.in);
		String mensaje="";
		System.out.println("Dime un caracter");
		caracter=sc.next().charAt(0);
		if(Character.isLowerCase(caracter)) {
			//System.out.println("Letra minuscula");
			mensaje="Letra minuscula";
		}else if(Character.isUpperCase(caracter)){
			//System.out.println("Letra mayuscula");
			mensaje="Letra mayuscula";
		}else if(Character.isDigit(caracter)) {
			//System.out.println("Digito entre 0 y 9");
			mensaje="Digito de 0 al 9";
		}else if(caracter==' '){
			//System.out.println("Espacios en blanco");
			mensaje="Espacios en blanco";
		}else if(caracter=='(' || caracter==')'){
			//System.out.println("Es una llave");
			mensaje="Es una llave";
		}else if(caracter=='{' || caracter=='}') {
			//System.out.println("Es una llave");
			mensaje="Es una llave";
		}else if(caracter=='.' || caracter==',' || caracter==':' || caracter==';' || caracter=='/') {
			//System.out.println("Es un tipo de puntuacion");
			mensaje="Es un tipo de puntuacion";
		}
		return mensaje;
	}
}
