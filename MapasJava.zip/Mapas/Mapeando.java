package Mapas;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Mapeando {
	List <Persona> personas;
	public Mapeando() {
		super();
		this.personas = new ArrayList <> ();
	}
	public Map mapearPersonasPorGenero(List<Persona> personas) {
		Map <Genero, List <Persona>> mapear= new HashMap <> ();
		for (Persona personaGenero: personas) {
			if(!mapear.containsKey(personaGenero.getGenero())) {
				mapear.put(personaGenero.getGenero(), personas);
			}
			mapear.get(personaGenero.getGenero()).add(personaGenero);
		}
		return mapear;
	}
	public Map<Integer, Integer> contarNumeros(Collection<Integer> numeros){
		Map<Integer, Integer> mapear= new HashMap <> ();
		for (int contar :numeros) {
			if(mapear.containsKey(contar)) {
				mapear.put(contar, 0);
			}else {
				mapear.put(contar, mapear.get(contar)+1);
			}
		}
		return mapear;
	}
	public static Collection<Integer> generarNumerosAleatorios(int size){
		List<Integer> numeros = new ArrayList<>();
			for(int i=0; i<size; i++) {
				numeros.add(new Random().nextInt(0, 20));
			}
		return numeros;
	}
}

