package Mapas;
public enum Genero {
	MASCULINO, FEMENINO, NEUTRO, DESCONOCIDO;
}