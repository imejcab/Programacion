package Boletin3Java;
import java.util.Scanner;
public class Ejercicio8 {
	public static void main(String [] args) {
		/* Diseñar una función que reciba como parámetro tres cadenas, la primera será una
frase y deberá buscar si existe la palabra que recibe como segundo parámetro y
reemplazarla por la tercera.*/
		Scanner sc=new Scanner (System.in);
		System.out.println("Dime una cadena de texto");
		String cadena=sc.nextLine();
		System.out.println("Dime una palabra para buscarla");
		String palabra=sc.nextLine();
		System.out.println("Dime una palabra para reemplazar");
		String palabraReemplazar=sc.nextLine();
		System.out.println(palabraReemplazada(cadena, palabra, palabraReemplazar));
	}
	public static String palabraReemplazada(String cadena, String palabra, String palabraReemplazar) {
		boolean esEncontrada=Ejercicio7.buscarPalabra(cadena,palabra);
		if(esEncontrada==true) {
			return cadena.replace(palabra,palabraReemplazar);
		}else {
			return cadena;
		}
	}
}
