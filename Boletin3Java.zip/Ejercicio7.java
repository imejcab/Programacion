package Boletin3Java;
import java.util.Scanner;
public class Ejercicio7 {
	public static void main(String [] args) {
		/*Realizar una función que busque una palabra escondida dentro de un texto. Por
ejemplo, si la cadena es “shybaoxlna” y la palabra que queremos buscar es “hola”,
entonces si se encontrará y deberá devolver True, en caso contrario deberá devolver
False. Las letras de la palabra escondida deben aparecer en el orden correcto en la
cadena que la oculta:
shybaoxlna ⇒ hola: True
soybahxlna ⇒ hola: False*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime una cadena de texto");
		String cadena=sc.nextLine();
		System.out.println("Dime que palabra quieres buscar");
		String palabra=sc.nextLine();
		System.out.println(buscarPalabra(cadena,palabra));
	}
	public static boolean buscarPalabra(String cadena, String palabra) {
		int contador=0;
		boolean palabraEncontrada=false;
		for(int i=0; i<cadena.length();i++) {
			if(cadena.charAt(i)==palabra.charAt(contador)) {
				contador++;
				if(contador==palabra.length()-1) {
					palabraEncontrada=true;
					i=cadena.length();
				}
			}
		}
		return palabraEncontrada;
	}
}
