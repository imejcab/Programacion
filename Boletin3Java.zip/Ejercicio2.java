package Boletin3Java;
import java.util.Scanner;
public class Ejercicio2 {
	public static void main(String [] args) {
		/*Un número es divisible por 3 si la suma de todas sus cifras reducidas a una cifra es
igual a 0, 3, 6 ó 9.
Por ejemplo, 156 ⇒ 1+5+6=12 ⇒ 1+2 = 3 es divisible,
pero 157 ⇒ 1+5+7 =13 ⇒ 1+3 =4 no lo es.
Elabora un programa que compruebe la divisibilidad por 3 según este algoritmo. El
programa debe comprobar que el número facilitado es válido.*/
		Scanner sc=new Scanner(System.in);
		int contador=0;
		String numero="";
		do {
			if(contador==0) {
				System.out.println("Dime un numero");
				numero=sc.nextLine();
			}
			if(!Character.isDigit(numero.charAt(contador))) {
				contador=0;
			}else {
				contador++;
			}
		}while(contador<numero.length());
		System.out.println(esDivisible(numero));
	}
	public static boolean esDivisible(String numero) {
		boolean es_divisible;
		int acumulador=0;
		for(int contador=0;contador<numero.length();contador++) {
			acumulador+=Integer.valueOf(numero.charAt(contador));
		}
		if(acumulador%3==0) {
			es_divisible=true;
		}else {
			es_divisible=false;
		}
		return es_divisible;
	}
}
