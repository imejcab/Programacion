package Boletin3Java;
import java.util.Scanner;
public class Ejercicio3 {
	public static void main(String [] args) {
		/* Diseña un programa que cuente el número de veces que aparece una palabra en
una cadena de texto.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduce una cadena de texto");
		String cadena=sc.nextLine();
		System.out.println("Dime una palabra");
		String palabra=sc.nextLine();
		System.out.println("La palabra " + palabra + " tiene " + contarRepeticionesPalabra(cadena,palabra) + " repeticiones ");
	}
	public static Integer contarRepeticionesPalabra(String cadena, String palabra) {
		int repeticiones=0;
		int contador=0;
		while(contador<cadena.length()) {
			if(cadena.indexOf(palabra, contador)!=-1) {
				repeticiones++;
				contador=cadena.indexOf(palabra,contador)+1;
			}else {
				contador=cadena.length();
			}
		}
		return repeticiones;
	}
}
