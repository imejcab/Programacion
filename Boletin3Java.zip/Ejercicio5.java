package Boletin3Java;
import java.util.Scanner;
public class Ejercicio5 {
	public static void main(String[] args) {
		/* Diseña una función llamada esPalindromo que reciba una cadena de caracteres y
determine si constituye un palíndromo o no. Una palabra es un palíndromo si puede
leerse del mismo modo de izquierda a derecha que de derecha a izquierda. Obvia
los espacios en blanco y caracteres separadores, así como tildes, etc.
Ejemplos de palíndromos: ‘Ligar es ser ágil’, ‘Somos o no somos’.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime una cadena para ver si es palindromo");
		String cadena=sc.nextLine();
		System.out.println(esPalindromo(cadena));
	}
	public static boolean esPalindromo(String cadena) {
		boolean es_palindromo=true;
		String cadenaSinEspacios=cadena.replace(" ","");
		for (int i=0; i<cadenaSinEspacios.length();i++) {
			if(cadenaSinEspacios.charAt(i)!=cadenaSinEspacios.charAt(cadenaSinEspacios.length()-1-i)){
				es_palindromo=false;
			}
		}
		return es_palindromo;
	}
}
