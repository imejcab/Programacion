package Boletin3Java;
import java.util.Scanner;
public class Ejercicio4 {
	public static void main(String [] args) {
		/*Crea tres funciones cuyo comportamiento sea como el de los métodos de String
startsWirth, contains y endsWith, pero sin utilizar ninguno de ellos.*/
		Scanner sc= new Scanner (System.in);
		System.out.println("Dime una cadena de texto");
		String cadena=sc.nextLine();
		System.out.println("Dime una palabra para buscarla");
		String palabra=sc.nextLine();
		System.out.println(startWith(cadena,palabra));
		System.out.println(contains(cadena,palabra));
		System.out.println(endWith(cadena,palabra));
	}
	public static boolean startWith(String cadena, String palabra) {
		boolean es_coincidencia=true;
		for(int i=0;i<palabra.length(); i++) {
			if(cadena.charAt(i)!=palabra.charAt(i)){
				es_coincidencia=false;
			}
		}
		return es_coincidencia;
	}
	public static boolean contains(String cadena, String palabra) {
		boolean es_coincidencia=true;
		for(int i=0;i<palabra.length(); i++) {
			if(cadena.indexOf(palabra)==-1){
				es_coincidencia=false;
			}
		}
		return es_coincidencia;
	}
	public static boolean endWith(String cadena, String palabra) {
		boolean es_coincidencia=true;
		int contador=palabra.length();
		for(int i=cadena.length()-1;i+palabra.length()>cadena.length()-1; i--) {
			contador--;
			if(cadena.charAt(i)!=palabra.charAt(contador)){
				es_coincidencia=false;
			}
		}
		return es_coincidencia;
	}
}
