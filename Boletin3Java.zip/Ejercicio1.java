package Boletin3Java;
import java.util.Scanner;
public class Ejercicio1 {
	public static void main(String [] args) {
		/*Escribe una función que reciba una cadena de texto y una variable bandera
(par/impar) e imprima solo los caracteres que se encuentran situados en las
posiciones pares o impares (según indique la variable bandera).
Desarrolla el código con un bucle for y después modifica el código para que utilice
una estructura while y do-while.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime una cadena:");
		String cadena=sc.nextLine();
		String bandera="";
		do {
			System.out.println("Dime par o impar");
			bandera=sc.nextLine();
		}while(!bandera.equals("par") && !bandera.equals("impar"));
		System.out.println(escogerParImpar(cadena, bandera));
	}
	public static String escogerParImpar(String cadena,String bandera) {
		//int contador=0;
		StringBuilder sbpar=new StringBuilder ("");
		StringBuilder sbimpar=new StringBuilder ("");
		
		/*while(contador<cadena.length()) {
			if(contador%2==0) {
				sbpar.append(cadena.charAt(contador));
				contador++;
			}else {
				sbimpar.append(cadena.charAt(contador));
				contador++;
			}
		}
		if(bandera.equals("par")) {
			return sbpar.toString();
		}else {
			return sbimpar.toString();
		}*/
		for(int contador=0; contador<cadena.length();contador++) {
			if(contador%2==0) {
				sbpar.append(cadena.charAt(contador));
			}else {
				sbimpar.append(cadena.charAt(contador));
			}
		}
		if(bandera.equals("par")) {
			return sbpar.toString();
		}else {
			return sbimpar.toString();
		}
		}
}

