package Boletin3Java;
import java.util.Scanner;
public class Ejercicio10 {
	static Scanner sc=new Scanner (System.in);
	public static final String ABECEDARIO="abcdefghijklmnñopqrstuvwxyz";
	public static final int DESPLAZAMIENTO=200;
	public static void main(String [] args) {
		/*0. El cifrado César es un tipo de cifrado por sustitución en el que una letra del alfabeto
es sustituida por otra que se encuentra situada en el abecedario
(abcdefghijklmnñopqrstuvwxyz) un número dado de posiciones desde la primera,
como puede observarse en la siguiente imagen:
Así, por ejemplo, la palabra CASADO, con un cifrado de tres posiciones pasaría a
ser FDVDGR.
a. Realiza una función que cifre un carácter según el cifrado César y un
desplazamiento dado.
b. Elabora una función que, haciendo uso de la anterior, reciba una palabra y un
número fijo de posiciones y la codifique según este algoritmo.
c. Diseña otra función que reciba dos palabras y compruebe si son equivalentes
según este tipo de cifrado e indique el nivel de sustitución utilizado, es decir,
si cifrando una de ellas podemos obtener la otra.
Ej: Si recibe CASADO y FDVDGR debe indicar que son equivalentes
y utilizan un nivel de codificación 3
Si recibe CASADO y AAAABD debe indicar que no son equivalentes.
El programa no debe distinguir entre mayúsculas y minúsculas.*/
		System.out.println("Dime un caracter");
		String caracter=sc.nextLine();
		System.out.println("Dime una palabra");
		String palabra1=sc.nextLine();
		System.out.println(codificarPalabra(palabra1));
		System.out.println("Dime una palabra");
		String palabra2=sc.nextLine();
		System.out.println(palabrasEquivalentes(palabra1,palabra2));
	}
	public static Integer mostrarDesplazamiento(char caracter) {
		int movimiento=ABECEDARIO.indexOf(caracter)+DESPLAZAMIENTO;
		return movimiento;
	}
	public static String codificarPalabra(String palabra1) {
		int contador=0;
		int contador_abecedario=0;
		StringBuilder sb=new StringBuilder ();
		while(contador<palabra1.length()) {
			if(palabra1.charAt(contador)==ABECEDARIO.charAt(contador_abecedario)) {
				if(mostrarDesplazamiento(ABECEDARIO.charAt(contador_abecedario))> ABECEDARIO.length()-1) {
					int posicion=(mostrarDesplazamiento(ABECEDARIO.charAt(contador_abecedario))%ABECEDARIO.length()-1);
					sb.append(ABECEDARIO.charAt(posicion));
					contador++;
					contador_abecedario=0;
				}else {
					sb.append(ABECEDARIO.charAt(mostrarDesplazamiento(ABECEDARIO.charAt(contador_abecedario))));
					contador++;
					contador_abecedario=0;
				}
			}else {
				contador_abecedario ++;
			}
		}
		return sb.toString();
	}
	public static boolean palabrasEquivalentes(String palabra1, String palabra2) {
		boolean es_equivalente;
		if(palabra1.equalsIgnoreCase(codificarPalabra(palabra2))) {
			es_equivalente=true;
		}else {
			es_equivalente=false;
		}
		return es_equivalente;
	}
}
