package Boletin3Java;
import java.util.Scanner;
public class Ejercicio6 {
	public static void main(String [] args) {
		/*Haciendo uso de la función anterior crea una función esCapicúa que acepte
números tanto enteros como decimales.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduce un numero");
		//Double numeroEntero=Double.valueOf(sc.nextLine());
		int numeroEntero=Integer.valueOf(sc.nextLine());
		System.out.println(esCapicua(numeroEntero));
	}
	public static boolean esCapicua(int numeroEntero) {
		boolean es_Capicua;
		String numeroString=String.valueOf(numeroEntero);
		es_Capicua=Ejercicio5.esPalindromo(numeroString);
		return es_Capicua;
	}
}
