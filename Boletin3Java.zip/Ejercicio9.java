package Boletin3Java;
import java.util.Scanner;
public class Ejercicio9 {
	public static void main(String [] args) {
		/* Escribir una función que devuelva el número de palabras, frases y párrafos que
existen en una cadena de texto que recibe como parámetro. Ten en cuenta que entre
dos palabras puede haber más de un blanco, las frases se separan por puntos y los
párrafos por saltos de línea.*/
		Scanner sc=new Scanner (System.in);
		System.out.println("Dime una cadena de texto");
		String cadena=sc.nextLine();
		System.out.println(contarPalabras(cadena));
		System.out.println(contarFrases(cadena));
		System.out.println(contarParrafos(cadena));
	}
	public static Integer contarPalabras(String cadena) {
		int palabra=0;
		int contador=0;
		int contador_repeticion=0;
		while(contador<cadena.length()-1) {
			if(Character.isWhitespace(cadena.charAt(contador))) {
				palabra++;
				contador++;
				contador_repeticion++;
				if(contador_repeticion>1) {
					palabra--;
				}
			}else {
				contador++;
				contador_repeticion=0;
			}
		}
		return palabra;
	}
	public static Integer contarFrases(String cadena) {
		int frase=0;
		int contador=0;
		while(contador<cadena.length()) {
			if(cadena.charAt(contador)=='.') {
				frase++;
				contador++;
			}else {
				contador++;
			}
		}
		return frase;
	}
	public static Integer contarParrafos(String cadena) {
		int parrafo=0;
		int contador=0;
		while(contador<cadena.length()-1) {
			if(cadena.charAt(contador)=='\n') {
				parrafo++;
				contador++;
			}else {
				contador++;
			}
		}
		return parrafo;
	}
}
