package LuchaPokemon;

import java.util.Objects;
import java.util.Random;

public class Pokemon{
	public static final int NIVELMINIMO=3;
	private String nombre;
	private Elemento elemento;
	protected int fuerza;
	private int nivel;
	public Pokemon(String nombre, Elemento elemento) {
		super();
		this.nombre = nombre;
		this.elemento = elemento;
		this.fuerza = obtenerFuerzaInicial();
		this.nivel = NIVELMINIMO;
	}
	private int obtenerFuerzaInicial() {
		int fuerza=new Random().nextInt(1,80);
		return fuerza;
	}
	public String getNombre() {
		return nombre;
	}
	public Elemento getElemento() {
		return elemento;
	}
	public int hashCode() {
		return Objects.hash(elemento, nombre);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Pokemon other = (Pokemon) obj;
		if(elemento == other.elemento && Objects.equals(nombre, other.nombre)) {
			resultado=true;
		}
		return resultado;
	}
	public int compareTo(Pokemon e) {
		int resultado=0;
		if(this.nombre==null) {
			resultado=1;
		}else if( e.nombre==null) {
			resultado=-1;
		}else {
			resultado=this.nombre.compareTo(e.nombre);
		}
		return resultado;
	}
}
