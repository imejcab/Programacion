package LuchaPokemon;
import java.util.Scanner;
public class PrincipalJava {
	public static void main(String [] args){
		Entrenador a =new Entrenador("Ash");
		Entrenador b =new Entrenador("Team Rocket");
		Pokemon pikachu=new Pokemon("pikachu", Elemento.AGUA);
		Pokemon snorlax=new Pokemon("snorlax", Elemento.AGUA);
		Pokemon raichu=new Pokemon("raichu", Elemento.AGUA);
		Pokemon moltres=new Pokemon("moltres", Elemento.AGUA);
		Pokemon magicard=new Pokemon("magicard", Elemento.AGUA);
		Pokemon meow=new Pokemon("meow", Elemento.AGUA);
		try {
			a.addPokemon(meow);
		} catch (ExceptionEntrenador e) {
			assert(false);
		}
		try {
			a.addPokemon(moltres);
		} catch (ExceptionEntrenador e) {
			assert(false);
		}
		System.out.println(a.mostrarPokemon());
		try {
			a.eliminarPokemon(meow);
		} catch (ExceptionEntrenador e) {
			assert(false);
		}
		System.out.println(a.mostrarPokemon());
		a.vaciarEquipo();
		System.out.println(a.mostrarPokemon());
		try {
			b.addPokemon(meow);
		} catch (ExceptionEntrenador e) {
			assert(false);
		}
		try {
			a.donar(b);
		} catch (ExceptionEntrenador e) {
			assert(false);
		}
		System.out.println(b.mostrarPokemon());
		System.out.println(snorlax.fuerza);
		System.out.println(b.obtenerMasFuerte());
	}
}
