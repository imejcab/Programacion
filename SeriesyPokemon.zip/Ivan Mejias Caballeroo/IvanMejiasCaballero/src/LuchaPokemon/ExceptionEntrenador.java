package LuchaPokemon;

public class ExceptionEntrenador extends Exception {

	public ExceptionEntrenador() {
	}
	public ExceptionEntrenador(String message) {
		super(message);
	}
	public ExceptionEntrenador(String message, Throwable cause) {
		super(message, cause);
	}
}
