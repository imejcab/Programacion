package LuchaPokemon;

public enum  Elemento {
	BICHO, DRAGON, HADA, LUCHA, PLANTA, AGUA, FUEGO, VENENO, NORMAL, ACERO;
	
}

