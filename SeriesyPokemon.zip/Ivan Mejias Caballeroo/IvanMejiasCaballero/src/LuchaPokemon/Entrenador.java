package LuchaPokemon;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;

public class Entrenador {
	public static final int BATALLASGANADASINICIO=0;
	private String nombre;
	private int batallasGanadas;
	Set <Pokemon> equipo;
	//La coleccion es un conjunto porque no pueden repetirse los pokemons en un mismo equipo y el orden no importa
	public Entrenador(String nombre) {
		super();
		this.nombre = nombre;
		this.batallasGanadas = BATALLASGANADASINICIO;
		this.equipo = new HashSet <> ();
	}
	public int hashCode() {
		return Objects.hash(nombre);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Entrenador other = (Entrenador) obj;
		if(Objects.equals(nombre, other.nombre)) {
			resultado=true;
		}
		return resultado;
	}
	public String toString() {
		return String.format("El entrenador " + nombre + ", tiene " + batallasGanadas + " batallas ganadas, su equipo es " + equipo);
	}
	public boolean addPokemon(Pokemon e) throws ExceptionEntrenador {
		boolean esAñadido=false;
		for(Pokemon poke: equipo) {
			if(poke.equals(e)) {
				throw new ExceptionEntrenador("Este pokemon esta en nuestro equipo");
			}
			this.equipo.add(e);
			esAñadido=true;
		}
		return esAñadido;
	}
	public boolean eliminarPokemon(Pokemon e) throws ExceptionEntrenador {
		boolean esEliminado=false;
		for(Pokemon poke:equipo) {
			if(poke.equals(e)) {
				equipo.remove(poke);
				esEliminado=true;
			}
		}
		if(equipo.isEmpty() || esEliminado==false) {
			throw new ExceptionEntrenador("Este pokemon no esta en nuestro equipo");
		}
		return esEliminado;
	}
	public boolean eliminarPokemon(String nombre, Elemento tipo) throws ExceptionEntrenador {
		boolean esEliminado=false;
		for(Pokemon poke:equipo) {
			if(poke.getNombre().equalsIgnoreCase(nombre) && poke.getElemento().equals(tipo)) {
				equipo.remove(poke);
				esEliminado=true;
			}
			if(equipo.isEmpty() || esEliminado==false) {
				throw new ExceptionEntrenador("Este pokemon no esta en nuestro equipo");
			}
		}
		return esEliminado;
	}
	public void vaciarEquipo() {
		if(!this.equipo.isEmpty()) {
			equipo.clear();
		}
	}
	protected Pokemon obtenerMasFuerte() {
		Pokemon masFuerte=null;
		int fuerza=0;
		for(Pokemon poke:equipo) {
			if(poke.fuerza>fuerza) {
				masFuerte=poke;
				fuerza=poke.fuerza;
			}
		}
		return masFuerte;
	}
	public void competir(Entrenador otro) {
		otro.obtenerMasFuerte();
	}
	public String mostrarPokemon() {
		StringBuilder sb= new StringBuilder();
		Map <Elemento, Pokemon> mapear= new HashMap <> ();
		Iterator<Entry<Elemento, Pokemon>> it= mapear.entrySet().iterator();
		for(;it.hasNext();) {
			Entry<Elemento, Pokemon> p=it.next();
			sb.append(p);
		}
		return sb.toString();
	}
	public boolean donar(Entrenador e) throws ExceptionEntrenador {
		boolean esDonado=false;
		for(Pokemon poke:equipo) {
			if(e.equipo.contains(poke)) {
				throw new ExceptionEntrenador("El pokemon esta en su equipo y no puedes donar");
			}
		}
		e.equipo.addAll(this.equipo);
		esDonado=true;
		return esDonado;
	}
}
