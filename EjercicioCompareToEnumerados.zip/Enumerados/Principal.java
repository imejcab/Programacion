package Enumerados;
import java.util.Scanner;
import java.util.Arrays;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
public class Principal {
	Scanner sc=new Scanner(System.in);
	public static void gestionPersona(String [] args) {
		Persona Pipe= new Persona("Felipe", "Mejias", Genero.HOMBRE, LocalDate.of(2000,12,3));
		Persona Ana= new Persona("Ana", "Mejias", Genero.MUJER, LocalDate.of(2006,12,3));
		Persona Juan= new Persona("Juan", "Mar", Genero.HOMBRE, LocalDate.of(1998,12,3));
		Persona Isabel= new Persona("Isabel", "Vaena", Genero.MUJER, LocalDate.of(2000,12,3));
		String generoString=null;
		Genero generoIntroducido=null;
		LocalDate fechaNacimiento=LocalDate.of(1999, 4, 3);
		LocalTime momento=LocalTime.of(15, 20, 30);
		LocalDate fecha=LocalDate.now();
		LocalDateTime fechaNacimientoYHora=LocalDateTime.of(fechaNacimiento, momento);
		do {
			try {
				System.out.println("Introduzca el genero");
				generoIntroducido=Genero.valueOf(generoString.toUpperCase());
			}catch(Exception e) {
				System.out.println("El valor introducido no es correcto");
			}
		}while(generoIntroducido==null);
		System.out.println(Pipe.getFechaNacimiento());
		Persona [] grupo= new Persona [6];
		grupo[0]=Pipe;
		grupo[1]=Ana;
		grupo[2]=Juan;
		grupo[3]=Isabel;
		Arrays.sort(grupo);
		System.out.println(Arrays.toString(grupo));
	}
}
