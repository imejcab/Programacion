package Enumerados;
import java.time.LocalDate;
public class Persona {
	/*atributos*/
	private String nombre;
	private String apellidos;
	private Genero genero;
	private LocalDate fechaNacimiento;
	/*constructor*/
	public Persona(String nombre, String apellidos, Genero genero, LocalDate fechaNacimiento) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.genero = genero;
		this.fechaNacimiento = fechaNacimiento;
	}
	/*metodos*/
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public Genero getGenero() {
		return genero;
	}
	public void setGenero(Genero genero) {
		this.genero = genero;
	}
	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public Integer compareTo(Persona Pipe) {
		int resultado=0;
		if(Pipe.getGenero().equals(Genero.HOMBRE) && this.getGenero().equals(Genero.HOMBRE)) {
			resultado=0;
		}else if(Pipe.getGenero().equals(Genero.HOMBRE) && this.getGenero().equals(Genero.MUJER)){
			resultado=1;
		}
		else{
			resultado=-1;
		}
		return resultado;
	}
	
}
