package Enumerados;
public enum Genero {
	HOMBRE,
	MUJER;
}
