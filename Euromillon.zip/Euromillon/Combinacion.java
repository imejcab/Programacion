package Euromillon;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
public class Combinacion {
	public static final int VALORMINIMO=1;
	public static final int VALORMAXIMONUMEROS=50;
	public static final int VALORMAXIMOESTRELLAS=12;
	public static final int TOTALNUMEROS=5;
	public static final int TOTALESTRELLAS=2;
	Set <Integer> numeros;
	Set <Integer> estrellas;
	public Combinacion(Integer [] numeros, Integer [] estrellas) {
		super();
		if(numeros.length==TOTALNUMEROS || estrellas.length==TOTALESTRELLAS) {
			this.numeros = new HashSet <> ();
			this.estrellas = new HashSet <> ();
		}
	}
	public static Integer[] toArrayEnteros (Integer ... enteros) {
		return enteros;
	}
	public Combinacion(int num1, int num2, int num3, int num4, int num5, int star1, int star2) {
		this(toArrayEnteros(num1, num2, num3, num4, num5), toArrayEnteros(star1, star2));
		if((num1>VALORMINIMO && num2>VALORMINIMO && num3>VALORMINIMO && num4>VALORMINIMO && num5>VALORMINIMO && star1>VALORMINIMO && star2> VALORMINIMO) && (num1<VALORMAXIMONUMEROS && num2<VALORMAXIMONUMEROS && num3<VALORMAXIMONUMEROS && num4<VALORMAXIMONUMEROS && num5<VALORMAXIMONUMEROS && star1<VALORMAXIMOESTRELLAS && star2<VALORMAXIMOESTRELLAS)) {
		}
	}
	public Combinacion(Set<Integer> numeros2, Set<Integer> estrellas2) {
		super();
		if(numeros.size()==TOTALNUMEROS || estrellas.size()==TOTALESTRELLAS) {
			this.numeros = new HashSet <> ();
			this.estrellas = new HashSet <> ();
		}
	}
	public Set<Integer> getNumeros() {
		return numeros;
	}
	public Set<Integer> getEstrellas() {
		return estrellas;
	}
	public int hashCode() {
		return Objects.hash(estrellas, numeros);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado=false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Combinacion other = (Combinacion) obj;
		if(Objects.equals(estrellas, other.estrellas) && Objects.equals(numeros, other.numeros)) {
			resultado=true;
		}
		return resultado;
	}
	public String toString() {
		return String.format("La combinacion ganadora en el sorteo es" + numeros + estrellas + "]");
	}
	/*abstract public int comprobarAciertos(Combinacion e) {
		
	}*/
}
