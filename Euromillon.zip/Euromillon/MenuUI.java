package Euromillon;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MenuUI {
	public void GestionSorteo(){
		Set <Integer> numeros= new HashSet <> ();
		Set <Integer> estrellas= new HashSet <> ();
		Combinacion a=new Combinacion(numeros, estrellas);
		Historial e= new Historial();
		try {
			e.addSorteo(LocalDate.now(), a);
		} catch (ExceptionHistorial e1) {
			e1.printStackTrace();
		}
		try {
			e.addSorteo(2000, 12, 3, a);
		} catch (ExceptionHistorial e1) {
			e1.printStackTrace();
		}
		try {
			e.BorrarSorteo(LocalDate.of(2002, 3, 2));
		} catch (ExceptionHistorial e1) {
			e1.printStackTrace();
		}
		System.out.println(e.listarSorteosDesdeFecha(LocalDate.now()));
		try {
			e.modificarSorteo(LocalDate.of(2020, 5, 7), a);
		} catch (ExceptionHistorial e1) {
			e1.printStackTrace();
		}
		System.out.println(e.mostrarHistorico());
	}
}
