package Euromillon;

public class ExceptionCombinacion extends Exception {

	public ExceptionCombinacion() {
	}

	public ExceptionCombinacion(String message) {
		super(message);
	}

	public ExceptionCombinacion(Throwable cause) {
		super(cause);
	}

	public ExceptionCombinacion(String message, Throwable cause) {
		super(message, cause);
	}

	public ExceptionCombinacion(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
