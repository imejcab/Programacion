package SieteyMedia;
import java.util.Scanner;
import java.util.Arrays;
public class Principal {
	public static void main(String [] args) {
		Baraja barajaEsp= new Baraja();
		System.out.println(Arrays.toString(args));
		barajaEsp.barajarCartas();
		System.out.println(barajaEsp);
	}
}
