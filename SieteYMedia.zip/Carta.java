package SieteyMedia;
import java.util.Objects;
import java.util.Random;
public class Carta {
	/*Atributos*/
	Palo Palo;
	Integer value;
	/*Constructor*/
	public Carta(SieteyMedia.Palo palo, Integer value) throws Exception {
		super();
		if(value<1 || value>12 || value==8 || value==9) {
			throw new Exception ("El valor aplicado no es posible y es un error");
		}
		Palo = palo;
		this.value = value;
		
	}
	public Palo getPalo() {
		return Palo;
	}
	public double getValue() {
		return this.value>9 ? 0.5 : this.value;
	}
	public int hashCode() {
		return Objects.hash(Palo, value);
	}
	public boolean equals(Object obj) {
		boolean resultado=false;
		if (this == obj) {
			resultado=true;
		}else if (obj == null) {
			resultado= false;
		}else if (getClass() != obj.getClass()) {
			resultado=false;
		}
		Carta other = (Carta) obj;
		if(Palo == other.Palo && Objects.equals(value, other.value)) {
			resultado=true;
		}
		return resultado;
	}
	public String toString() {
		return "Carta [Palo=" + Palo + ", value=" + value + "]";
	}
	
}
