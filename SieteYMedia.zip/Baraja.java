package SieteyMedia;
import java.util.Arrays;
import java.util.concurrent.*;
public class Baraja {
	/*Atributos*/
	protected Carta [] cartas;
	private final static int MAX_SIZE=40;
	protected int siguiente;
	/*CONSTRUCTOR*/
	public Baraja() {
		this.siguiente=0;
		this.cartas=new Carta [MAX_SIZE];
		int posicion=0;
		for (Palo palo: Palo.values()){
			for(int i=1; i<13; i++) {
				if(i!=8 && i!=9) {
					try {
						this.cartas[posicion ++]= new Carta (palo, i);
					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	public void barajarCartas() {
		int posicion=0;
		for (Palo palo: Palo.values()){
			for(int i=1; i<13; i++) {
				posicion=(int) (Math.random()*30+1);
				cartas[i]=cartas[posicion];
			}
	}
	}	
	public Carta getSiguiente() {
		return this.cartas[siguiente++%MAX_SIZE];
	}
	public String toString() {
		return String.format("Baraja [cartas=" + Arrays.toString(cartas) + ", siguiente=" + siguiente + "]");
	}
	private int generaNumero() {
		return ThreadLocalRandom.current().nextInt(0,MAX_SIZE);
	}
}
