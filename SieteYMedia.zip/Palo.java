package SieteyMedia;

public enum Palo {
	ORO,
	BASTO,
	ESPADA,
	COPA;
}
