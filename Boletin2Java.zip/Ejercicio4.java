package Boletin2Java;
import java.util.Scanner;
public class Ejercicio4 {
	public static void main(String [] args) {
		/*Elabora un programa que codifique una cadena, de tal modo que en el resultado se
inviertan cada 2 caracteres. Los caracteres intercambiados no pueden volver a
intercambiarse. Ejemplo:
Entrada -> Hola mundo
Salida -> oHalm nuod*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime una cadena");
		String cadena=sc.nextLine();
		System.out.println(revertirCadena(cadena));
	}
	public static String revertirCadena(String cadena) {
		String mensaje="";
		for(int contador=0; contador<cadena.length()-1;contador+=2) {
			mensaje+=cadena.charAt(contador+1);
			mensaje+=cadena.charAt(contador);
		}
		return mensaje;
	}
}
