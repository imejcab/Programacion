package Boletin2Java;
import java.util.Scanner;
public class Ejercicio7 {
	public static void main(String[] args) {
		/*Realizar un método llamado segundosEntre que recibirá seis valores enteros, los
tres primeros representarán la hora, minuto y segundos de la primera hora y los
otros tres de la segunda hora. Se deberá devolver el número de segundos que hay
entre la primera hora y la segunda (el valor debe ser siempre en positivo). Si los
datos no son correctos se deberá devolver -1000.*/
		/*Cifrador cesar para un caracter y cifrador cesar para una cadena.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduce una hora");
		int hora1=Integer.valueOf(sc.nextLine());
		System.out.println("Introduce los minutos");
		int minuto1=Integer.valueOf(sc.nextLine());
		System.out.println("Introduce los segundos");
		int segundo1=Integer.valueOf(sc.nextLine());
		System.out.println("Introduce una hora");
		int hora2=Integer.valueOf(sc.nextLine());
		System.out.println("Introduce los minutos");
		int minuto2=Integer.valueOf(sc.nextLine());
		System.out.println("Introduce los segundos");
		int segundo2=Integer.valueOf(sc.nextLine());
		System.out.println(segundosEntre(hora1,minuto1,segundo1,hora2,minuto2,segundo2));
	}
	public static Integer segundosEntre(int hora1, int minuto1, int segundo1, int hora2, int minuto2, int segundo2) {
		int diferencia_segundos;
		if((hora1>hora2) || (hora1==hora2 && minuto1>minuto2) || (hora1==hora2 && minuto1==minuto2 && segundo1>segundo2)) {
			diferencia_segundos=((hora1-hora2)*3600)+((minuto1-minuto2)*60) + (segundo1-segundo2);
		}else if((hora1<hora2) || (hora1==hora2 && minuto1<minuto2) || (hora1==hora2 && minuto1==minuto2 && segundo1<segundo2)) {
			diferencia_segundos=((hora2-hora1)*3600)+((minuto2-minuto1)*60) + (segundo2-segundo1);
		}else{
			diferencia_segundos=0;
		}
		if((hora1<0 || hora2<0 || minuto1<0 || minuto2<0 || segundo1<0 || segundo2<0 || hora1>24 || hora2>24 || minuto1>60 || minuto2>60 || segundo1>60 || segundo2>60)) {
			diferencia_segundos=-1000;
		}
		return diferencia_segundos;
	}
}
