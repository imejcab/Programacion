package Boletin2Java;
import java.util.Scanner;
public class Ejercicio3 {
	public static void main(String [] args) {
		/*Diseña una función que, dada una cadena de entrada, comprueba si es una
contraseña fuerte o no. Se considera que una contraseña es fuerte si contiene 8 o
más caracteres, y entre ellos al menos hay una mayúscula, una minúscula, un signo
de puntuación y al menos un dígito*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime una contrasena");
		String contrasena=sc.nextLine();
		System.out.println(contrasenaSegura(contrasena));
	}
	public static boolean contrasenaSegura(String contrasena) {
		boolean es_segura=true;
		int contador=0;
		while(contador<contrasena.length()) {
			if(Character.isLowerCase(contrasena.charAt(contador))){
				contador=contrasena.length();
				}else {
					contador++;
					if(contador==contrasena.length()) {
						es_segura=false;
					}
			}
		}
		if(es_segura=true) {
			contador=0;
		}
		while(contador<contrasena.length()) {
			if(Character.isUpperCase(contrasena.charAt(contador))){
				contador=contrasena.length();
				}else {
					contador++;
					if(contador==contrasena.length()) {
						es_segura=false;
					}
			}
		}
		if(es_segura=true) {
			contador=0;
		}
		while(contador<contrasena.length()) {
			if(Character.isDigit(contrasena.charAt(contador))){
				contador=contrasena.length();
				}else {
					contador++;
					if(contador==contrasena.length()) {
						es_segura=false;
					}
			}
		}
		if(es_segura=true) {
			contador=0;
		}
		while(contador<contrasena.length()) {
			if(contrasena.charAt(contador)==':' || contrasena.charAt(contador)=='=' || contrasena.charAt(contador)==';' || contrasena.charAt(contador)=='+') {
				contador=contrasena.length();
			}else {
				contador+=1;
				if(contador==contrasena.length()) {
					es_segura=false;
				}
			}
		}
		if(contrasena.length()<8) {
			es_segura=false;
		}
		return es_segura;
		}
	}

