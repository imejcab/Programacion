package Boletin2Java;
import java.util.Scanner;
public class Ejercicio1 {
	public static void main(String [] args) {
		/*1. Realizar un método llamado numeroSolucionesEcuacionSegundoGrado que reciba
los coeficientes de una ecuación de segundo grado y devuelva el número de
soluciones que tiene. Si los argumentos no son válidos (el primer coeficiente tiene
que ser distinto de cero) debe devolver un -1.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime cuanto vale a");
		int a=Integer.valueOf(sc.nextLine());
		System.out.println("Dime cuanto vale b");
		int b=Integer.valueOf(sc.nextLine());
		System.out.println("Dime cuanto vale c");
		int c=Integer.valueOf(sc.nextLine());
		System.out.println(numeroSolucionesEcuacionSegundoGrado1(a, b, c));
		System.out.println(numeroSolucionesEcuacionSegundoGrado1(a, b, c));
	}
	public static double numeroSolucionesEcuacionSegundoGrado1(int a, int b, int c) {
		double coeficiente_1=(((((Math.pow(b,2)-4*a*c)))*0.5)/2*a) + (-b/2*a);
		return coeficiente_1;
	}
	public static double numeroSolucionesEcuacionSegundoGrado2(int a, int b, int c) {
		double coeficiente_2=(((((Math.pow(b,2)-4*a*c)))*0.5)/2*a) - (-b/2*a);
		return coeficiente_2;
	}
}
