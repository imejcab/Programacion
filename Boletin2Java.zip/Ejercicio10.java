package Boletin2Java;
import java.util.Scanner;
public class Ejercicio10 {
	public static void main(String[] args) {
		/*Realiza un método llamado gcd (greaterCommonDivisor) que recibirá dos números y
devuelva el máximo común divisor según el algoritmo de Euclides.
MCD(A,B)=MCD(B,C). MCD(A,B)=MCD(B,A-B).*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime el valor del numero 1");
		int numero1=Integer.valueOf(sc.nextLine());
		System.out.println("Dime el valor del numero 2");
		int numero2=Integer.valueOf(sc.nextLine());
		System.out.println(gcd(numero1,numero2));
	}
	public static Integer gcd(int numero1, int numero2) {
		int numero3=numero1-numero2;
		int maxComunDivisor1y2Euclides=0;
		for(int contador=numero1-1;contador>0;contador--) {
			if(numero1%contador==0 && numero2%contador==0 && numero3%contador==0) {
				maxComunDivisor1y2Euclides=contador;
				contador=0;
			}
		}
		return maxComunDivisor1y2Euclides;
	}
}