package Boletin2Java;
import java.util.Scanner;
public class Ejercicio6 {
	public static void main(String [] args){
		/*Realizar un método llamado horaMayor que recibirá seis valores enteres, los tres
primeros representarán la hora, minuto y segundos de la primera hora y los otros
tres de la segunda hora. Se deberá devolver un 1 si la primera hora es mayor que la
segunda, un 2 si la segunda hora es mayor que la primera, un 0 si son iguales y un
-1000 si los datos no son correctos.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime cuantas horas pasaron");
		int hora1=Integer.valueOf(sc.nextLine());
		System.out.println("Dime cuantos minutos pasaron");
		int minuto1=Integer.valueOf(sc.nextLine());
		System.out.println("Dime cuantos segundos pasaron");
		int segundo1=Integer.valueOf(sc.nextLine());
		System.out.println("Dime cuantas horas pasaron");
		int hora2=Integer.valueOf(sc.nextLine());
		System.out.println("Dime cuantos minutos pasaron");
		int minuto2=Integer.valueOf(sc.nextLine());
		System.out.println("Dime cuantos segundos pasaron");
		int segundo2=Integer.valueOf(sc.nextLine());
		System.out.println(obtenerHoraMayor(hora1,hora2,minuto1,minuto2,segundo1,segundo2));
	}
	public static Integer obtenerHoraMayor(int hora1, int minuto1, int segundo1, int hora2, int minuto2, int segundo2) {
		int resultado;
		if((hora1>hora2) || (hora1==hora2 && minuto1>minuto2) || (hora1==hora2 && minuto1==minuto2 && segundo1>segundo2)) {
			resultado=1;
		}else if((hora1<hora2) || (hora1==hora2 && minuto1<minuto2) || (hora1==hora2 && minuto1==minuto2 && segundo1<segundo2)) {
			resultado=2;
		}else {
			resultado=0;
		}
		if(hora1<0 || hora2<0 || minuto1<0 || minuto2<0 || segundo1<0 || segundo2<0 || hora1>24 || hora2>24 || minuto1>60 || minuto2>60 || segundo1>60 || segundo2>60) {
			resultado=-1000;
		}
		return resultado;
	}
}
