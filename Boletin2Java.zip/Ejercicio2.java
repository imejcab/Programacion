package Boletin2Java;
import java.util.Scanner;
public class Ejercicio2 {
	public static void main(String [] args) {
		/* Realiza un programa que pida un número por teclado y que después muestre ese
número al revés.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime un numero");
		String numero=sc.nextLine();
		String invertida="";
		for(int contador=numero.length()-1; contador>=0; contador--) {
			invertida+=(numero.charAt(contador));
		}
		System.out.println(invertida);
	}
}
