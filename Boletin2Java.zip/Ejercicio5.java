package Boletin2Java;
import java.util.Scanner;
public class Ejercicio5 {
	public static void main(String [] args) {
		/*Realizar un método llamado esMultiplo que recibirá dos números y devuelva True si
el primer número es múltiplo del segundo.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime un numero");
		int numero1=Integer.valueOf(sc.nextLine());
		System.out.println("Introduce un numero");
		int numero2=Integer.valueOf(sc.nextLine());
		System.out.println(esMultiplo(numero1,numero2));
	}
	public static Boolean esMultiplo(int numero1, int numero2) {
		boolean es_multiplo=false;
		if(numero2%numero1==0) {
			es_multiplo=true;
		}
		return es_multiplo;
	}
}
