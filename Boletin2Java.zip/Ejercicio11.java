package Boletin2Java;
import java.util.Scanner;
public class Ejercicio11 {
	public static void main(String [] args) {
		/*Realizar un método llamado minimoComunMultiplo que reciba dos números y
calcule el mínimo común múltiplo de dos números. Con el máximo común divisor de
una pareja de números podemos obtener fácilmente el mínimo común múltiplo de
dicha pareja. El mínimo común múltiplo de dos números es igual al producto de los
números dividido entre su máximo común divisor. Por ejemplo, el máximo común
divisor de 24 y 36 es 12, por tanto el mínimo común múltiplo de 24 y 36 es
(24×36)/12=72.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime un valor para el numero1");
		int numero1=Integer.valueOf(sc.nextLine());
		System.out.println("Dime un valor para el numero1");
		int numero2=Integer.valueOf(sc.nextLine());
		System.out.println("El minimo Comun Multiplo es: " + minimoComunMultiplo(numero1,numero2));
	}
	public static Integer minimoComunMultiplo(int numero1, int numero2) {
		int maxComunDivisor1y2=0;
		for(int contador=numero1-1;contador>1;contador--) {
			if(numero1%contador==0 && numero2%contador==0) {
				maxComunDivisor1y2=contador;
				contador=0;
			}
		}
		int minimoComunMultiplo=(numero1*numero2)/maxComunDivisor1y2;
		return minimoComunMultiplo;
	}
}
