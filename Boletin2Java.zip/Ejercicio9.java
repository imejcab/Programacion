package Boletin2Java;
import java.util.Scanner;
public class Ejercicio9 {
	public static void main(String [] args) {
		/*9. Realiza un método llamado toDecimal que reciba un String con un valor decimal
como argumento y devuelva un número con el número decimal correspondiente.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime una cadena numerica");
		String numero_cadena=sc.nextLine();
		int contador=0;
		do {
			if(!Character.isDigit(numero_cadena.charAt(contador))) {
				contador=0;
				System.out.println("Dime una cadena numerica");
				numero_cadena=sc.nextLine();
			}
			contador++;
		}while(contador<numero_cadena.length());
		System.out.println(toDecimal(numero_cadena));
	}
	public static Integer toDecimal(String numero_cadena) {
		int numeroInt=Integer.parseInt(numero_cadena);
		/*int numeroInt=Integer.valueOf(numero_cadena);*/
		return numeroInt;
	}
}
