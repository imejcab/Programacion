package Boletin2Java;
import java.util.Scanner;
public class Ejercicio8 {
	public static final int DIV=2;
	public static void main(String [] args) {
		/*Realiza un método llamado toBinary que reciba un número decimal como
argumento y devuelva un String con el número binario correspondiente.*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Dime un numero decimal por favor");
		int numero=Integer.valueOf(sc.nextLine());
		System.out.println(toBinario(numero));
	}
	public static String toBinario(int numero) {
		int resto;
		StringBuilder sb=new StringBuilder ();
		while(numero>=1) {
			resto=numero%2;
			numero=numero/DIV;
			sb.append(resto);
		}
		sb.reverse();
		return sb.toString();
	}
}
